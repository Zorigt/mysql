Use a_oe;

/*  demo 01  */
create or replace view  a_oe.custReportGoodCredit_01 as 
select 
   cust_id as CustomerID
,  concat(cust_name_first,  ' ',  cust_name_last) as CustomerName
from  a_oe.customers
where credit_limit > 3000;


/*  demo  02  */	
Desc a_oe.custReportGoodCredit_01;

/*  demo 03  */	
Select CustomerName, CustomerID 
From a_oe.custReportGoodCredit_01
Order by CustomerID;


/*  demo 04  */	
Create or replace view  a_oe.ordReport_01 as 
Select 
   ord_id      as OrderID 
,  cast(ord_date as date)    as OrderDate
,  cust_id     as CustomerID
,  concat(cust_name_first,  ' ',  cust_name_last) as CustomerName
,  prod_id     as ItemPurchased
,  prod_name   as ItemDescription
,  quoted_price * quantity_ordered as LineTotal
From  a_oe.customers
Join  a_oe.order_headers  using (cust_id)
Join  a_oe.order_details using(ord_id)
Join  a_prd.products using(prod_id)
Where quoted_price > 0 and quantity_ordered > 0;


/*  demo 05  */	
Desc a_oe.ordReport_01;

/*  demo  06  */	
Select orderid, orderdate, itempurchased, linetotal
From a_oe.ordreport_01;


/*  demo  07  */	
Select orderid, orderdate, itempurchased 
From a_oe.ordreport_01
Where orderdate < '2013-01-01';


/*  demo 08  */	
Select orderid, orderdate, itempurchased 
From a_oe.ordreport_01
Where month(orderdate) in (1,2,3)
And year(orderdate) in (2013)
Limit 8;


/*  demo 09  */
Select orderid, orderdate, itempurchased, linetotal
From a_oe.ordreport_01
Where linetotal < 100
Limit 8;


/*  demo  10  */
Select orderid
, itempurchased
, warehouse_id
, quantity_on_hand
, linetotal
From a_oe.ordreport_01 RPT
Join a_prd.inventory  PRD  on RPT.itempurchased = PRD.prod_id
Where linetotal >500
And quantity_on_hand < 100
;


/*  demo 11  */	
create or replace view  a_oe.ordreport_02(orderid, orderdate, customerid, linetotal) as 
select 
   ord_id      
,  ord_date    
,  cust_id     
,  quoted_price * quantity_ordered 
From  a_oe.order_headers  
Join  a_oe.order_details using(ord_id)
Join  a_prd.products using(prod_id)
Where quoted_price > 0 and quantity_ordered > 0
Order by ord_id
;


/*  demo 12  */
show create view a_oe.ordreport_01\G

/*  demo 13  */	
Select table_schema, table_name, table_type 
From information_schema.tables 
Where table_schema = "a_oe";

