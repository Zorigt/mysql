Use a_testbed;

/*  Demo 01  */
Select *
From ( 
   Select * 
   From a_emp.jobs
   ) tbl;

Select job_Id, job_title, max_salary
From ( 
   Select job_Id, job_title, max_salary 
   From a_emp.jobs
   Where max_salary is not null
   ) tbl
;


/*  Demo 02  */
Select COUNT(DISTINCT shipping_mode) as num_diff_ship_modes
From a_oe.order_headers;


/*  Demo 03  */
Select count(distinct coalesce(shipping_mode, 'none')) as num_diff_ship_modes
From a_oe.order_headers;


/*  Demo 04  */
Select count(*) as num_diff_ship_modes
From (
   Select distinct shipping_mode
   From a_oe.order_headers
   ) tbl;


/*  Demo 05  */
Select distinct shipping_mode, ord_mode
From a_oe.order_headers
Order by shipping_mode, ord_mode;


/*  Demo 06  */
Select count(*) as num_diff_modes
From (
   Select distinct shipping_mode, ord_mode
   From a_oe.order_headers
   ) tbl;


/*  Demo 07  */
Select count(distinct shipping_mode, ord_mode) as  num_diff_modes
From a_oe.order_headers;


/*  Demo 08  */
Select D.dept_id, count(*)
From  A_emp.departments  D
Left join a_emp.employees E on D.dept_id = E.dept_id
Group by D.dept_id;


/*  Demo 09  */
Select D.dept_id, count(E.emp_id)
From a_emp.departments  D
Left join a_emp.employees E on D.dept_id = E.dept_id
Group by D.dept_id
;


/*  Demo 10  */
Select D.dept_id, D.dept_name, count(E.emp_id)
From a_emp.departments  D
Left join a_emp.employees E on D.dept_id = E.dept_id
Group by D.dept_id;


/*  Demo 11  */
Select dept_id, count(*) as EmpCount
From a_emp.employees E
Group by dept_id;


/*  Demo 12  */
Select D.dept_id, D.dept_name, EC.EmpCount
From a_emp.departments D
Left join (
   Select dept_id, count(*) as EmpCount
   From a_emp.employees
   Group by dept_id
   ) EC  on D.dept_id = EC.dept_id 
   ;


/*  Demo 13  */
Select 
  D.dept_id
, D.dept_name
, concat(l.loc_city, ' ',  l.loc_state_province)  as Location
, coalesce(EmpCount,0) as EmpCount
From a_emp.departments D
Join a_emp.locations L on D.loc_id = l.loc_id
Left join ( 
   Select dept_id, count(emp_id) as EmpCount 
   From a_emp.employees E
   Group by dept_id
   ) EC on D.dept_id = EC.dept_id
;


/*  Demo 14  */
Select 
  dept_id
, dept_count
, Round((dept_count / Count_All),2) AS Percnt
From 
   (Select dept_id, count(1) AS dept_count  /* get count by department */
    From a_emp.employees
    Group by dept_id)  vt1,   /* get total count for all employees */ 
   (Select count(*) AS Count_All
    From a_emp.employees)   vt2
Order by Dept_id;


/*  Demo 15  */
Select 
  dept_id
, dept_count
, concat(Round((100. * dept_count / Count_All),0), '%') AS Percnt
From 
   (Select dept_id, count(1) AS dept_count  
    From a_emp.employees
    Group by dept_id)  vt1, 
   (Select count(*) AS Count_All
    From a_emp.employees)   vt2
Order by Dept_id;


/*  Demo 16  */
Select distinct tblapl.custid
From 
    (Select CustID
     From a_oe.cust_orders
     Where category ='APL' 
     )  tblapl 
 Join
    (Select CustID
     From  a_oe.cust_orders
     Where Category ='HW' 
     )  tblhw  
   On tblapl.custid = tblhw.custid     
;


/*  Demo 17  */
Select CS.cust_id, CS.credit_limit, CR.rating
From a_oe.customers  CS
Join a_oe.credit_ratings CR on CS.credit_limit 
      between CR.low_limit and CR.high_limit;


/*  Demo 18  */
Select 'under paid' as catg, 0 as low, 19999.99 as high 
union all
Select 'medium paid' as catg, 20000.00 as low, 79999.99 as high 
union all
Select 'over paid' as catg, 80000.00 as low, 9999999.99 as high ;


/*  Demo 19  */
Select emp_id, name_last,salary, catg
From a_emp.employees E
Join (
     Select 'under paid' as catg, 0 as low, 19999.99 as high   union all
     Select 'medium paid' as catg, 20000.00 as low, 79999.99 as high 
   union all
     Select 'over paid' as catg, 80000.00 as low, 9999999.99 as high 
  ) Ratings on E.salary between Ratings.low and Ratings.high
Order by salary
;


/*  Demo 20  */
Select emp_id, name_last,salary 
,  case 
     when salary between 0 and 19999.99 then 'under paid'
     when salary between 20000.00 and 79999.99 then 'medium paid'
     when salary between 80000.00 and 9999999.99 then 'over paid'
   end as catg
From a_emp.employees E
Order by salary;


/*  Demo 21  */
Select catg, count(*)as NumEmployees
From   a_emp.employees E
Join (
  Select 'under paid' as catg, 0 as low, 19999.99 as high 
  union all
  Select 'medium paid' as catg, 20000.00 as low, 79999.99 as high 
  union all
  Select 'over paid' as catg, 80000.00 as low, 9999999.99 as high 
  ) Ratings on E.salary between Ratings.low and Ratings.high
Group by catg;


