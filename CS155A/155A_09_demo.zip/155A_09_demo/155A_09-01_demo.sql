Use a_vets;

/*  demo 01   */	
Select
  an_id
, an_name
From a_vets.vt_animals
Where an_type = 'cat'
Union
Select
  an_id
, an_name
From a_vets.vt_animals
Where an_type = 'dog';


/*  demo 02   */	
Select
  an_id
, an_name
From a_vets.vt_animals
Where an_type = 'cat'
Union
Select
  an_id
, an_dob
From a_vets.vt_animals
Where an_type = 'dog';

/*  demo 03   */	
Select
  an_id
, an_name
From a_vets.vt_animals
Where an_type = 'cat'
Union
Select
  an_id
, CAST(an_dob As char(10))
From a_vets.vt_animals
Where an_type = 'dog';

Use a_oe;

/*  demo 04   */	
Select
  ord_id
, prod_id
, catg_id
, prod_name
From a_oe.order_details
Join a_prd.products Using (prod_id)
Where catg_id In ('PET', 'SPG')
Order By ord_id
;

/*  demo 05   */	
Select
  ord_id
, prod_id
, catg_id
, prod_name
From a_prd.products
Join a_oe.order_details
Using (prod_id)
Where catg_id = 'PET'
Union All
Select
  ord_id
, prod_id
, catg_id
, prod_name
From a_prd.products
Join a_oe.order_details
Using (prod_id)
Where catg_id = 'SPG'
Order By ord_id
;

/*  demo 06   */	
   select   ord_id, prod_id, catg_id, prod_name
   from     a_prd.products join a_oe.order_details using (prod_id)
   where    catg_id = 'PET' 
UNION ALL
   select   ord_id, prod_id
   from     a_prd.products join a_oe.order_details using (prod_id)
   where    catg_id = 'SPG' 
order by ord_id
;

/*  demo 07   */	
Select
  name_last
, name_first
, 'Employee' As "Pers Type"
From a_emp.employees
Union All
Select
  cust_name_last
, cust_name_first
, 'Customers'
From a_oe.customers
;

/*  demo 08   */	
Select
  prod_id
, catg_id
, prod_name
From a_prd.products
Join a_oe.order_details Using (prod_id)
Join a_oe.order_headers Using (ord_id)
Where catg_id = 'HW'
And EXTRACT(Month From ord_date) = 11
Union All
Select
  prod_id
, catg_id
, prod_name
From a_prd.products
Join a_oe.order_details Using (prod_id)
Join a_oe.order_headers Using (ord_id)
Where catg_id = 'HW'
And EXTRACT(Month From ord_date) = 12
Order By prod_id
;

/*  demo 09   */	
Select
  prod_id
, catg_id
, prod_name
From a_prd.products
Join a_oe.order_details Using (prod_id)
Join a_oe.order_headers Using (ord_id)
Where catg_id = 'HW'
And EXTRACT(Month From ord_date) = 11
Union
Select
  prod_id
, catg_id
, prod_name
From a_prd.products
Join a_oe.order_details Using (prod_id)
Join a_oe.order_headers Using (ord_id)
Where catg_id = 'HW'
And EXTRACT(Month From ord_date) = 12
;

/*  demo 10   */	
Select
  prod_id As "Product ID"
, prod_list_price As "List Price"
From a_prd.products
Where catg_id = 'APL'
Union All
Select
  '---- Avg Price for all Appliances ----'
, AVG(prod_list_price)
From a_prd.products
Where catg_id = 'APL'
;


/*  demo 11   */	
Use a_testbed;

Create Table d_set_emp (
  E_id int
, E_name varchar(10)
, E_city varchar(10)
);

Create Table d_set_cust (
  C_id int
, C_name varchar(10)
, C_city varchar(10)
);

Insert Into d_set_emp
  Values (101, 'Jones', 'Chicago');
Insert Into d_set_emp
  Values (102, 'Anderson', 'Chicago');
Insert Into d_set_emp
  Values (103, 'Baxter', 'Chicago');
Insert Into d_set_emp
  Values (104, 'Johnson', 'Chicago');
Insert Into d_set_emp
  Values (105, 'Miller', 'Chicago');

Insert Into d_set_cust
  Values (201, 'Oliver', 'Boston');
Insert Into d_set_cust
  Values (202, 'Athena', 'Boston');
Insert Into d_set_cust
  Values (203, 'Sanders', 'Boston');
Insert Into d_set_cust
  Values (204, 'Baxter', 'Boston');

/*  demo 12   */	
Select
  E_id
, E_name
, E_city
From d_set_emp
Union All
Select
  C_id
, C_name
, C_city
From d_set_cust;


/*  demo 13   */	
Select
  E_id
, E_name
, E_city
From d_set_emp
Union All
Select
  C_id
, C_name
, C_city
From d_set_cust
Order By E_name; /*  demo 14   */	
(
  Select
    E_id
  , E_name
  , E_city
  From d_set_emp
  Order By E_name
)
Union All (
  Select
    C_id
  , C_name
  , C_city
  From d_set_cust
  Order By c_name
); /*  demo 15   */	
(
  Select
    E_id
  , E_name
  , E_city
  From d_set_emp
  Order By E_name Limit 2
)
Union All (
  Select
    C_id
  , C_name
  , C_city
  From d_set_cust
  Order By c_name Limit 2
); /*  demo 16   */	
(
  Select
    E_id
  , E_name
  , E_city
  From d_set_emp
  Order By E_name Limit 200
)
Union All (
  Select
    C_id
  , C_name
  , C_city
  From d_set_cust
  Order By c_name Limit 200
);