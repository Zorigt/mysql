Use a_oe;

/*  demo 01  */
Select
  credit_limit
From a_oe.customers
Where cust_id In (
  Select
    cust_id
  From a_oe.order_headers
)
Order By credit_limit Desc;

/*  demo 02   */	
Select
  cust_name_last
, cust_name_first
, cust_id
From a_oe.customers
Where cust_id In (
  Select
    cust_id
  From a_oe.order_headers
  Where ord_id In (
    Select
      ord_id
    From a_oe.order_details
    Where prod_id = 1020
  )
)
Order By cust_id
;

/*  demo 03   */	
Select Distinct
  CS.cust_name_last
, CS.cust_name_first
, CS.cust_id
From a_oe.customers CS
Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
Join a_oe.order_details OD On OH.ord_id = OD.ord_id
Where OD.prod_id = 1020
Order By cust_id
;

/*  demo 04   */	
Select
  cust_name_last
, cust_name_first
, cust_id
From a_oe.customers
Where cust_id In (
  Select
    cust_id
  From a_oe.order_headers
  Where ord_id In (
    Select
      ord_id
    From a_oe.order_details
    Where prod_id In (
      Select
        prod_id
      From a_prd.products
      Where catg_id = 'APL'
    )
  )
)
Order By cust_id
;

/*  demo 05   */	
Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where cust_id = (
  Select
    cust_id
  From a_oe.order_headers
  Where Ord_id = 115
);

/*  demo 06   */	
Set @prod_id    */= 5004;

Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where cust_id = (
  Select
    cust_id
  From a_oe.order_headers OH
  Join a_oe.order_details OD On OH.ord_id = OD.ord_id
  Where prod_id = @prod_id
);



/*  demo 07   */	
Set @empId    */= 145;

Select
  emp_id
From a_emp.employees
Where emp_id <> @empId
And emp_mng = (
  Select
    emp_mng
  From a_emp.employees
  Where emp_id = @empId
);


/*  demo 08   */	
Set @empId = 100;

Select
  emp_id
From a_emp.employees
Where emp_id <> @empId
And emp_mng = (
  Select
    emp_mng
  From a_emp.employees
  Where emp_id = @empId
);


/*  demo 09   */	
Set @empId    */= 408;
Select
  emp_id
From a_emp.employees
Where emp_id <> @empId
And emp_mng = (
  Select
    emp_mng
  From a_emp.employees
  Where emp_id = @empId
);



/*  demo 10   */	
Select
  prod_id
, prod_name
, catg_id
, prod_list_price
From a_prd.products
Where prod_list_price > (
  Select
    AVG(prod_list_price)
  From a_prd.products
);


/*  demo 11   */	
Select
  prod_id
, prod_name
, catg_id
, prod_list_price
From a_prd.products
Where prod_list_price Between (
  Select
    AVG(prod_list_price)
  From a_prd.products
) - 100
And (
  Select
    AVG(prod_list_price)
  From a_prd.products
) + 100
;



/*  demo 12   */	
Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where cust_id = (
  Select
    cust_id
  From a_oe.order_headers
  Where ord_date = '2011-11-28'
);

/*  demo 13   */	
Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where cust_id In (
  Select
    cust_id
  From a_oe.order_headers
  Where ord_date = '2011-11-28'
);

/*  demo 14   */	
Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where cust_id In (
  Select
    cust_id
  From a_oe.order_headers
  Where ord_date = '1888-08-08'
);

/*  demo 15   */	
Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where cust_id Not In (
  Select
    cust_id
  From a_oe.order_headers
  Where ord_date = '1888-08-08'
);


/*  demo 16   */	
Select
  a_oe.customers.cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Join a_oe.order_headers On a_oe.customers.cust_id = a_oe.order_headers.cust_id
Where MONTH(ord_date) = 12
And YEAR(ord_date) = 2011
;

/*  demo 17   */	
Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where cust_id In (
  Select
    cust_id
  From a_oe.order_headers
  Where MONTH(ord_date) = 12
  And YEAR(ord_date) = 2011
);

/*  demo 18   */	
Select
  CS.cust_id
, CS.cust_name_last
From a_oe.customers CS
Left Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
Where OH.ord_id Is Null
;

/*  demo 19   */	
Select
  a_oe.customers.cust_id
, cust_name_last
From a_oe.customers
Where cust_id Not In (
  Select
    cust_id
  From a_oe.order_headers
);

/*  demo 20   */	
Select
  Ord_id
, ord_date
From a_oe.order_headers
Where ord_id Not In (
  Select
    ord_id
  From a_oe.order_details
);


/*  demo 21   */	
Set @catg = 'PET';

Select
  prod_id
, prod_name
, catg_id
, prod_list_price
From a_prd.products
Where prod_list_price = (
  Select
    MAX(prod_list_price)
  From a_prd.products
  Where catg_id = @catg
);


/*  demo 22   */	
Select
  prod_id
, prod_name
, catg_id
, prod_list_price
From a_prd.products
Where catg_id = @catg
And prod_list_price = (
  Select
    MAX(prod_list_price)
  From a_prd.products
  Where catg_id = @catg
);


/*  demo 23   */	
Select Distinct
  cust_id
, prod_id
From a_oe.order_headers OH
Join a_oe.order_details OD On OH.ord_id = OD.ord_id
Where prod_id In (
  Select
    prod_id
  From a_prd.products
  Where catg_id = @catg
  And prod_list_price = (
    Select
      MAX(prod_list_price)
    From a_prd.products
    Where catg_id = @catg
  )
);

Set @catg = 'SPG';

/*  demo 24   */	
Create Or Replace View a_oe.oe_cust_orders
As (
  Select
    OH.ord_id As Invoice
  , OH.ord_date As OrderDate
  , OH.cust_id As CustID
  , PR.catg_id As Category
  , OD.prod_id As ItemPurchased
  From a_oe.order_headers OH
  Join a_oe.order_details OD On OH.ord_id = OD.ord_id
  Join a_prd.products PR On OD.prod_id = PR.prod_id
  Where OD.quoted_price > 0
  And OD.quantity_ordered > 0
);

/*  demo 25   */	
Select
  *
From a_oe.oe_cust_orders
Order By invoice, category;


/*  demo 26   */	
Select Distinct
  custid
, invoice
, category
From a_oe.oe_cust_orders
Where category <> 'APL'
And oe_cust_orders.invoice In (
  Select
    invoice
  From a_oe.oe_cust_orders
  Where category = 'APL'
)
Order By invoice
;


/*  demo 27   */	
Select Distinct
  custid
, invoice
, category
From a_oe.oe_cust_orders
Where Category <> 'APL'
And CustID In (
  Select
    custid
  From a_oe.oe_cust_orders
  Where category = 'APL'
)
Order By custid
;


/*  demo 28   */
Select
  cust_id
, cust_name_last
From a_oe.customers
Where cust_id In (
  Select
    custID
  From a_oe.oe_cust_orders
  Where category = 'APL'
)
And cust_id In (
  Select
    CustID
  From a_oe.oe_cust_orders
  Where Category = 'HW'
);

/*  demo 29   */	
Select Distinct
  cust_id
, cust_name_last
From a_oe.customers CS
Join a_oe.oe_cust_orders CO On CS.cust_id = CO.CustID
Where category = 'APL'
And category = 'HW';



/*  demo 30   */	
Select Distinct
  cust_id
, cust_name_last
From a_oe.customers CS
Join a_oe.oe_cust_orders CO On CS.cust_id = CO.CustID
Where category = 'APL'
Or category = 'HW';



/*  demo 31   */	

Select Distinct
  cust_id
, cust_name_last
, category
, itempurchased
From a_oe.customers CS
Join a_oe.oe_cust_orders CO On CS.cust_id = CO.CustID
Where CustID = '401250';

Select Distinct
  cust_id
, cust_name_last
, category
, itempurchased
From a_oe.customers CS
Join a_oe.oe_cust_orders CO On CS.cust_id = CO.CustID
Where CustID = '403000';