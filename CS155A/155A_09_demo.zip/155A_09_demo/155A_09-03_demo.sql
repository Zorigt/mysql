
/*  demo 01  */
Create Table d_enum_01 (
  ord_id int Not Null
, ord_mode varchar(15) Not Null
, Constraint ord_mode_ck Check (ord_mode In ('PHONE', 'ONLINE', 'DIRECT'))
) Engine = Innodb;

Insert Into d_enum_01
  Values (1, 'PHONE');
Insert Into d_enum_01
  Values (2, 'INTERNET');

Select
  *
From d_enum_01;

/*  demo 02  */
Create Table d_enum_02 (
  ord_id int Not Null
, ord_mode enum ('PHONE', 'ONLINE', 'DIRECT')
) Engine = Innodb;

Insert Into d_enum_02
  Values (1, 'PHONE');
Insert Into d_enum_02
  Values (2, 'INTERNET');
Insert Into d_enum_02
  Values (3, 'DIRECT');

Select
  *
From d_enum_02;


/*  demo 03  */
Update d_enum_02
Set ord_mode = 'ONLINE'
Where ord_id = 3;
Update d_enum_02
Set ord_mode = 'DOORTODOOR'
Where ord_id = 3;


/*  demo 04  */
Insert Into d_enum_02
  Values (4, 'Phone');
Insert Into d_enum_02
  Values (5, Null);
Insert Into d_enum_02
  Values (6, 'DIRECT');

Alter Table d_enum_02 Modify ord_mode enum ('PHONE', 'ONLINE', 'DIRECT', 'DOORTODOOR');
Insert Into d_enum_02
  Values (7, 'DOORTODOOR');

/*  demo 05  */
Select
  *
From d_enum_02
Order By ord_mode;

Select
  'DIRECT' * 1;


/*  demo 06  */
Select
  ord_id
, ord_mode
, ord_mode * 1
From d_enum_02;


/*  demo 07  */
Select
  *
From d_enum_02
Order By CAST(ord_mode As char);

Alter Table d_enum_02 Modify ord_mode enum ('DIRECT', 'DOORTODOOR', 'ONLINE', 'PHONE');

Select
  ord_id
, ord_mode
, ord_mode * 1
From d_enum_02
Order By ord_mode;

/*  demo 08  */
Select
  ord_id
, ord_mode
From d_enum_02
Where ord_mode = 'PHONE';

Select
  ord_id
, ord_mode
From d_enum_02
Where ord_mode = 3;


/*  demo 09  */
Create Table d_enum_03 (
  ord_id int Not Null
, ord_mode enum ('PHONE', 'ONLINE', 'DIRECT') Not Null Default 'DIRECT'
);

Insert Into d_enum_03 (ord_id)
  Values (33);
Select
  *
From d_enum_03;



/*  demo 10  */
Create Table d_enum_04 (
  ord_id int Not Null
, ord_mode enum ('PHONE', 'ONLINE', 'DIRECT') Not Null
);

Insert Into d_enum_04 (ord_id)
  Values (44);
Select
  *
From d_enum_04;


/*  demo 11  */
create table d_enum_05 ( 
  ord_id   int not null
, ord_mode varchar(15)  not null
);

Insert into d_enum_05(ord_id) Values (55);


/*  demo 12  */
Select
  SUM(ord_mode)
From d_enum_02;


Select
  ord_mode
, SQRT(ord_mode)
From d_enum_02;

/*  demo 13  */
Create Table d_set_01 (
  emp_id int
, emp_cert set ('Java', 'Visual Basic', 'C++', 'Database')
);


/*  demo 14  */
Insert Into d_set_01
  Values (1, Null);
Insert Into d_set_01
  Values (2, 'Java');


Insert Into d_set_01
  Values (3, 'Java,Database');

Insert Into d_set_01
  Values (4, 'Database,Java');

Insert Into d_set_01
  Values (5, 'Set Theory');

Insert Into d_set_01
  Values (6, 'Database, Java');


/*  demo 15  */
Select
  *
From d_set_01;

/*  demo 16  */
Truncate d_set_01;
Insert Into d_set_01
  Values (1, 'Java');
Insert Into d_set_01
  Values (2, 'Visual Basic');
Insert Into d_set_01
  Values (3, 'C++');
Insert Into d_set_01
  Values (4, 'Database');


Insert Into d_set_01
  Values (5, 'Java,Visual Basic');
Insert Into d_set_01
  Values (6, 'Java,C++');
Insert Into d_set_01
  Values (7, 'Java,Database');


Insert Into d_set_01
  Values (8, 'Visual Basic,C++');
Insert Into d_set_01
  Values (9, 'Visual Basic,Database');
Insert Into d_set_01
  Values (10, 'C++,Database');



Insert Into d_set_01
  Values (11, 'Visual Basic,C++,Database');
Insert Into d_set_01
  Values (12, 'Java,C++,Database');
Insert Into d_set_01
  Values (13, 'Java,Visual Basic,Database');
Insert Into d_set_01
  Values (13, 'Java,Visual Basic,C++');

Insert Into d_set_01
  Values (14, 'Java,Visual Basic,C++,Database');



/*  demo 17  */
Select
  emp_id
, emp_cert
, emp_cert * 1 As Intgr
, LPAD(BIN(emp_cert * 1), 4, '0') As bnry
From d_set_01
Order By bnry;


/*  demo 18  */
Select
  emp_id
, emp_cert
, emp_cert * 1 As Intgr
, LPAD(BIN(emp_cert * 1), 4, '0') As bnry
From d_set_01
Where emp_cert Like '%database%'
Order By bnry;



/*  demo 19  */
Select
  emp_id
, emp_cert
, emp_cert * 1 As Intgr
, LPAD(BIN(emp_cert * 1), 4, '0') As bnry
From d_set_01
Where emp_cert Like '%Java%'
Order By bnry;



/*  demo 20  */
Select
  emp_id
, emp_cert
, emp_cert * 1 As Intgr
, LPAD(BIN(emp_cert * 1), 4, '0') As bnry
From d_set_01
Where emp_cert Like '%Basic%'
Order By bnry;

/*  demo 21  */
Select
  emp_id
, emp_cert
, emp_cert * 1 As Intgr
, LPAD(BIN(emp_cert * 1), 4, '0') As bnry
From d_set_01
Where emp_cert Like '%C++%'
Order By bnry;

/*  demo 22  */
Select emp_id, emp_cert
from d_set_01 
where emp_cert = 'C++';




/*  demo 23  */
Select
  column_name
, column_type
From information_schema.columns
Where table_schema = 'a_testbed'
And table_name = 'd_enum_02';


/*  demo 24  */
Select
  column_name
, column_type
From information_schema.columns
Where table_schema = 'a_testbed'
And table_name = 'd_set_01';


/*  demo 25  */
Select
  table_name
, column_name
, column_type
From information_schema.columns
Where table_schema = 'a_testbed'
And Column_type Like '%Basic%';


/*  demo 26  */
Select
  table_name
, column_name
, column_type
From information_schema.columns
Where table_schema = 'a_testbed'
And Column_type Like '%Phone%';


/*  demo 27*/
Select
  table_name
, column_name
, column_type
From information_schema.columns
Where table_schema = 'a_testbed'
And Column_type Like 'enum(%';