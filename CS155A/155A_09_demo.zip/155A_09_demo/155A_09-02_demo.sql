Use a_prd;

/*  demo 01   */	
Select
  prod_id
, catg_id
, prod_name
From a_prd.products
Where prod_id In (
  Select
    prod_id
  From a_oe.order_details
  Join a_oe.order_headers Using (ord_id)
  Where catg_id = 'HW'
  And EXTRACT(Month From ord_date) = 11
)
And prod_id In (
  Select
    prod_id
  From a_oe.order_details
  Join a_oe.order_headers Using (ord_id)
  Where catg_id = 'HW'
  And EXTRACT(Month From ord_date) = 12
);

/*  demo 02   */	
Select
  prod_id
, catg_id
, prod_name
From a_prd.products
Where prod_id In (
  Select
    prod_id
  From a_oe.order_details
  Join a_oe.order_headers Using (ord_id)
  Where catg_id = 'HW'
  And EXTRACT(Month From ord_date) = 11
)
And prod_id Not In (
  Select
    prod_id
  From a_oe.order_details
  Join a_oe.order_headers Using (ord_id)
  Where catg_id = 'HW'
  And EXTRACT(Month From ord_date) = 12
);

/*  demo 03   */	
Select
  prod_id
, catg_id
, prod_name
From a_prd.products
Where prod_id Not In (
  Select
    prod_id
  From a_oe.order_details
  Join a_oe.order_headers Using (ord_id)
  Where catg_id = 'HW'
  And EXTRACT(Month From ord_date) = 11
)
And prod_id In (
  Select
    prod_id
  From a_oe.order_details
  Join a_oe.order_headers Using (ord_id)
  Where catg_id = 'HW'
  And EXTRACT(Month From ord_date) = 12
);