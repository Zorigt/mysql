Use a_testbed;
/*  demo 01  */
Drop Table if exists a_testbed.ac_projects ;

Create Table a_testbed.ac_projects (
  prj_id int Primary Key
, prj_name varchar(20)
, prj_budget int
);

Insert Into a_testbed.ac_projects (prj_id, prj_name)  Values 
    (10, 'Snowball')
  , (20, 'Frosting')
  , (30, 'Sphinx')
  , (40, 'Kilimanjaro')
;

Select *
From a_testbed.ac_projects;

/*  demo 02  */
Insert Into a_testbed.ac_projects  Values (20, 'Icing', 450000);


/*  demo 03  */
Insert Into a_testbed.ac_projects  Values (20, 'Icing', 450000)
On Duplicate Key Update
  prj_name = 'Icing'
, prj_budget = 450000
;

Select *
From a_testbed.ac_projects;

/*  demo 04  */
Insert Into a_testbed.ac_projects (prj_name, prj_id, prj_budget)
  Values ('cupcake', 42, 12000)
On Duplicate Key Update
  prj_name = 'cupcake'
, prj_budget = 50000
;

Select *
From a_testbed.ac_projects;

/*  demo 05  */
Insert Into a_testbed.ac_projects (prj_name, prj_id, prj_budget)
  Values ('Catapult', 50, 586000)
On Duplicate Key Update
prj_name = VALUES(prj_name)
, prj_budget = VALUES(prj_budget)
;

Insert Into a_testbed.ac_projects (prj_name, prj_id, prj_budget)
  Values ('Crescent', 30, 4000)
On Duplicate Key Update
prj_name = VALUES(prj_name)
, prj_budget = VALUES(prj_budget)
;

/*  demo 06  */
Insert Into a_testbed.ac_projects (prj_name, prj_id, prj_budget)
  Values ('Crescent', 30, 2500)
On Duplicate Key Update
  prj_name = VALUES(prj_name)
, prj_budget = greatest(ac_projects.prj_budget, VALUES(prj_budget))
;

Select *
From a_testbed.ac_projects;

Insert Into a_testbed.ac_projects (prj_name, prj_id, prj_budget)
  Values ('Crescent', 30, 7500)
On Duplicate Key Update
  prj_name = VALUES(prj_name)
, prj_budget = greatest(ac_projects.prj_budget, VALUES(prj_budget))
;

Select *
From a_testbed.ac_projects;

/*  demo 07  */
Insert Into a_testbed.ac_projects (prj_name, prj_id, prj_budget)
  Values ('Godot', 101, 50001)
  , ('Milan', 102, 50002)
  , ('Omega', 030, 125000)
  , ('Palladium', 050, 50003)
  , ('Greenwich', 103, 50004)
  , ('Deco', 040, 50005)
  , ('Volta', 042, 50005)
On Duplicate Key Update
prj_name = VALUES(prj_name)
, prj_budget = greatest(ac_projects.prj_budget, VALUES(prj_budget))
;

Select *
From a_testbed.ac_projects;

/*  demo 08  */
Insert Into a_testbed.ac_projects (prj_name, prj_id, prj_budget)
  Values ('Volta', 042, Null)
On Duplicate Key Update
prj_budget = a_testbed.ac_projects.prj_budget * 1.5
;

Insert Into a_testbed.ac_projects (prj_name, prj_id, prj_budget)
  Values ('Volta', 043, Null)
On Duplicate Key Update
prj_budget = a_testbed.ac_projects.prj_budget * 1.5
;

Select *
From a_testbed.ac_projects;




/*  demo 09 */
truncate table a_testbed.ac_emp;

insert into ac_emp values
  (10, 'FREUD',  301, 30000, '2002-06-06', 'PERM')
, (20, 'MATSON', 201, 30000, NULL, 'PERM')
, (30, 'HANSON', 201, 40000, '2003-05-15', 'PERM')
, (40, 'IBSEN',  201, 45000, '2003-05-20', 'PERM')
, (50, 'MILES',  401, 25000, '2003-06-20', 'PERM')
, (60, 'TANG',   401, 25000, '2003-06-20', NULL)
, (70, 'KREMER', 501, 50000, '2003-07-15', NULL)
, (80, 'PAERT',  201, 65000, '2003-07-18', NULL)
, (90, 'JARRET', 301, 60000, '2003-08-08', NULL)
;

Select *
From ac_emp;


/*  demo 10 */
REPLACE INTO a_testbed.ac_emp (e_id, e_name, d_id, salary, hiredate, e_status)
values ( 101, 'Bensen', 201, 55000, null, null)
;

select * 
from a_testbed.ac_emp 
where e_id >= 90;

/*  demo 11 */
REPLACE INTO a_testbed.ac_emp (e_id, e_name, d_id, salary, hiredate, e_status)
values ( 90, 'Williams', 201, 22000, curdate(), null)
;
select * 
from a_testbed.ac_emp 
where e_id >= 90;

/*  demo 12 */
REPLACE INTO a_testbed.ac_emp (e_id, e_name, d_id, salary, hiredate, e_status)
values 
( 101, 'Danson', 201, 55000, null, null),
( 103, 'Denver', 301, 35800, '2009-01-25', 'PERM');

select * 
from a_testbed.ac_emp 
where e_id >= 90;

/*  demo 13 */
REPLACE INTO a_testbed.ac_emp
SET e_id = 104, e_name = 'Paulson', d_id = 401, salary = 45000;

select * 
from a_testbed.ac_emp 
where e_id >= 90;

/*  demo 14 */
REPLACE INTO a_testbed.ac_emp
SET e_id = 104, e_name = 'Peterson', d_id = 401, hiredate=curdate()
;

select * 
from a_testbed.ac_emp 
where e_id >= 90;

/*  demo 15 */
create table a_testbed.ac_emp_changes like ac_emp;

insert into a_testbed.ac_emp_changes values 
   ( 105, 'Adams',   401, 45900, '2010-04-15', 'PERM')
,  ( 106, 'Baker',   401, 35800, '2010-04-15', 'PERM')
,  (  90, 'Carlson', 401, 25700, '2010-04-15', 'PERM')
,  ( 101, 'Dobson',  401, 30300, '2010-04-15', 'PERM')
;

select * 
from a_testbed.ac_emp_changes;

/*  demo 16 */
replace into a_testbed.ac_emp
  select * 
  from a_testbed.ac_emp_changes;


select * 
from a_testbed.ac_emp 
where e_id >= 90;

/*  demo 17 */
create table a_testbed.ac_proj_1 ( e_id decimal(3,0), pr_id int
, constraint ac_proj_1_pk primary key(e_id, pr_id)
, constraint ac_proj_1_pk foreign key(e_id) references a_testbed.ac_emp(e_id)
);
insert into a_testbed.ac_proj_1  values ( 60, 101), (60, 102), (60, 103), (70,101);

create table a_testbed.ac_emp_changes2 like a_testbed.ac_emp;

truncate table a_testbed.ac_emp_changes2 ;
insert into a_testbed.ac_emp_changes2 values 
   ( 60, 'Adams',   401, 25000, '2003-06-20', null)
,  ( 70, 'Baker',   501, 50000, '2003-07-15', null)
,  ( 80, 'Charlie', 201, 65000, '2003-07-15', null);


/*  demo 18 */
replace into a_testbed.ac_emp
  Select * 
  From a_testbed.ac_emp_changes2;

  
  Drop table ac_proj_1 ; 
  
  
/*  demo 19 */
drop table if exists a_testbed.ac_proj_2;

create table a_testbed.ac_proj_2 ( e_id decimal(3,0), pr_id int
, constraint ac_proj2_pk primary key(e_id, pr_id)
, constraint ac_proj2_pk foreign key(e_id) references a_testbed.ac_emp(e_id) 
on delete cascade
);
insert into a_testbed.ac_proj_2  values ( 60, 101), (60, 102), (60, 103), (70,101), (80, 101), (90,101);


/*  demo 20 */
replace into a_testbed.ac_emp
   select * 
   from a_testbed.ac_emp_changes2;

Select * 
From a_testbed.ac_proj_2

/*  demo 21 */
Create table a_testbed.z_repl_test  (
   id     int primary key, 
   cl_id  int unique, 
   name   varchar(15)
   );
   
Insert into a_testbed.z_repl_test   values (1, 10, 'cat');
Insert into a_testbed.z_repl_test   values (2, 20, 'dog');

   
/*  demo 22 */
replace into a_testbed.z_repl_test values ( 3, 20, 'elephant');

Select * 
From a_testbed.z_repl_test;

/*  demo 23 */
replace into a_testbed.z_repl_test values ( 1, 20, 'fox');

Select * 
 From a_testbed.z_repl_test;


/*  demo 24 */
truncate table a_testbed.ac_emp_changes2;
insert into a_testbed.ac_emp_changes2 (e_id, e_name, d_id, salary) values
   (  60, 'Bobby',   401, 20900)
,  (  70, 'Billy',   501, 25000)
,  (  80, 'Bret',    201, 75000)
;


/*  demo 25 */
replace into a_testbed.ac_emp
select E.e_id, C.e_name, C.d_id
, greatest(coalesce(E.salary,0), coalesce(C.salary,0), 35000) salary
, date_add(E.hiredate, interval -6 month)   hiredate
, E.e_status
from a_testbed.ac_emp  E
join a_testbed.ac_emp_changes2  C  on E.e_id = C.e_id;

Select * 
From a_testbed.ac_emp 
Where e_id in (60,70,80);

