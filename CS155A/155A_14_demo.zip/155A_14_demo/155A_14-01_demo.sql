Use a_testbed;

/*  demo 01  */
Drop Table If Exists a_testbed.ddl_emp_proj;
Drop Table If Exists a_testbed.ddl_proj;
Drop Table If Exists a_testbed.ddl_emp;
Drop Table If Exists a_testbed.ddl_dept;


/*  demo 02	  */
Drop Table If Exists a_testbed.ddl_dept2;

Create Table a_testbed.ddl_dept2 (
  d_id numeric(3)
, d_name varchar(15)
) Engine = Innodb;


/*  demo 03  */
Insert Into a_testbed.ddl_dept2 (d_id, d_name)
  Values (10, 'Sales');

/*  demo 04  */
Insert Into a_testbed.ddl_dept2 (d_id, d_name)
  Values (Null, Null);

/*  demo 05  */
Insert Into a_testbed.ddl_dept2 (d_id, d_name)
  Values (10, 'Marketing');

/*  demo 06  */
Insert Into a_testbed.ddl_dept2 (d_id, d_name)
  Values (40.8, 'Development');


/*  demo 07  */
Insert Into a_testbed.ddl_dept2 (d_id, d_name)
  Values (- 44, '');


/*  demo 08  */
Insert Into a_testbed.ddl_dept2 (d_id, d_name)
  Values (1234, 'Research');


/*  demo 09  */
Insert Into a_testbed.ddl_dept2 (d_id, d_name)
  Values (20, 'Accounting and Payroll');


/*  demo 10  */
Insert Into a_testbed.ddl_dept2 (d_id, d_name)
  Values (35);


/*  demo 11  */
Insert Into a_testbed.ddl_dept2 (d_id)
  Values (35);


Select *
From a_testbed.ddl_dept2
Order By d_id;

Drop Table a_testbed.ddl_dept2;

/*  demo 12  */	
Create Table a_testbed.ddl_proj (
  p_id varchar(10)
, p_name varchar(15) Null
, Constraint ddl_proj_PK Primary Key (p_id)
, Constraint ddl_proj_P_Name_UN Unique (p_name)
) Engine = Innodb;



/*  demo 13  */
Create Table a_testbed.ddl_dept (
  d_id numeric(3)
, d_name varchar(15) Not Null
, Constraint ddl_dept_PK Primary Key (d_id)
, Constraint ddl_dept_D_Name_UN Unique (d_name)
) Engine = Innodb;


/*  demo 14  */
Create Table a_testbed.ddl_un (
  id numeric(3)
, city varchar(15)
, state char(2)
, Constraint location_UN Unique (city, state)
) Engine = Innodb;

Insert Into a_testbed.ddl_un (id, city, state)
  Values (1, 'Chicago', 'IL');
Insert Into a_testbed.ddl_un (id, city, state)
  Values (2, 'Chicago', 'CA');
Insert Into a_testbed.ddl_un (id, city, state)
  Values (3, 'Pekin', 'IL');

-- fails
Insert Into a_testbed.ddl_un (id, city, state)
  Values (4, 'Pekin', 'IL');

Insert Into a_testbed.ddl_un (id, city, state)
  Values (5, Null, Null);
Insert Into a_testbed.ddl_un (id, city, state)
  Values (6, Null, Null);


Select *
From a_testbed.ddl_un;

Drop Table a_testbed.ddl_un;


/*  demo 15  */
Create Table a_testbed.ddl_emp (
  e_id numeric(3)
, e_name varchar(15) Not Null
, d_id numeric(3) Not Null
, Constraint ddl_emp_pk Primary Key (e_id)
, Constraint ddl_emp_dept_fk Foreign Key (d_id) References a_testbed.ddl_dept (d_id)
) Engine = Innodb;


/*  demo 16  */
show create table a_testbed.ddl_emp\G


/*  demo 17  */
Create Table a_testbed.ddl_emp_proj (
  p_id varchar(10) Not Null
, Constraint ddl_emp_proj_proj_fk Foreign Key (p_id) References a_testbed.ddl_proj (p_id)
, e_id numeric(3) Not Null
, Constraint ddl_emp_proj_emp_fk Foreign Key (e_id) References a_testbed.ddl_emp (e_id)
, Constraint ddl_empproj_pk Primary Key (p_id, e_id)
) Engine = Innodb;


/*  demo 18  */
Create Table a_testbed.ddl_parent (
  p_id numeric(3) Primary Key
) Engine = Innodb;

Create Table a_testbed.ddl_child (
  c_id numeric(3) Primary Key
, fk_id numeric(3)
, Foreign Key (fk_id) References a_testbed.ddl_parent (p_id)
  On Delete Cascade
) Engine = Innodb;

Insert Into a_testbed.ddl_parent (p_id)   Values (1);
Insert Into a_testbed.ddl_parent (p_id)   Values (2);
Insert Into a_testbed.ddl_parent (p_id)   Values (3);

Insert Into a_testbed.ddl_child (c_id, fk_id)   Values (100, 2);
Insert Into a_testbed.ddl_child (c_id, fk_id)   Values (101, 2);
Insert Into a_testbed.ddl_child (c_id, fk_id)   Values (103, 2);
Insert Into a_testbed.ddl_child (c_id, fk_id)   Values (104, 3);

Select p_id, c_id, fk_id
From a_testbed.ddl_parent
Join a_testbed.ddl_child On a_testbed.ddl_parent.p_id = a_testbed.ddl_child.fk_id;

/*  demo 19  */
Delete
From a_testbed.ddl_parent
Where p_id = 2;

Select *
From a_testbed.ddl_parent;
Select  *
From a_testbed.ddl_child;

/*  demo 20  */
Drop Table a_testbed.ddl_child;

Create Table a_testbed.ddl_child (
  c_id numeric(3) Primary Key
, fk_id numeric(3)
, Foreign Key (fk_id) References a_testbed.ddl_parent (p_id)
  On Delete Set Null
) Engine = Innodb;

Insert Into a_testbed.ddl_parent (p_id)  Values (2);
Insert Into a_testbed.ddl_child (c_id, fk_id)  Values (100, 2);
Insert Into a_testbed.ddl_child (c_id, fk_id)  Values (101, 2);
Insert Into a_testbed.ddl_child (c_id, fk_id)  Values (103, 2);
Insert Into a_testbed.ddl_child (c_id, fk_id)  Values (104, 3);

delete
From a_testbed.ddl_parent
Where p_id = 2;

Select  *
From a_testbed.ddl_child;

Drop Table a_testbed.ddl_child;
Drop Table a_testbed.ddl_parent;


/*  demo 21  */
Create Table a_testbed.ddl_default (
  id numeric(3)
, d_state char(2) Default 'CA'
) Engine = Innodb;

Insert Into a_testbed.ddl_default (id, d_state)  Values (1, 'PA');
Insert Into a_testbed.ddl_default (id, d_state)  Values (2, 'CA');
Insert Into a_testbed.ddl_default (id, d_state)  Values (3, Default);
Insert Into a_testbed.ddl_default (id)  Values (4);

Select *
From a_testbed.ddl_default;


Drop Table a_testbed.ddl_default;


/*  demo 22  */
Create Table a_testbed.ddl_check (
  id numeric(3)
, d_state char(2)
, Constraint dstated_ck
  Check (d_state In ('CA', 'NV', 'IL'))
) Engine = Innodb;

Insert Into a_testbed.ddl_check (id, d_state)
  Values (1, 'CA');
Insert Into a_testbed.ddl_check (id, d_state)
  Values (2, 'IL');

-- this should fail but doesn't
Insert Into a_testbed.ddl_check (id, d_state)
  Values (3, 'NY');



Insert Into a_testbed.ddl_check (id, d_state)
  Values (4, Null);
Select
  *
From a_testbed.ddl_check;   


show create table a_testbed.ddl_check;

Drop Table a_testbed.ddl_check;

/*  demo 23  */
Create Table a_testbed.ddl_check (
  id numeric(3)
, weight numeric(3)
, Constraint weight_ck
  Check (weight Between 0 And 500)
) Engine = Innodb;

Insert Into a_testbed.ddl_check
  Values (1, 450);
Insert Into a_testbed.ddl_check
  Values (2, 950);

Drop Table a_testbed.ddl_check;


/*  demo 24  */
Create Table a_testbed.ddl_dept_2 (
  d_id numeric(3) Primary Key
, d_name varchar(15) Not Null
, d_city varchar(15) Not Null
, d_state char(2)
, d_phone varchar(10)
, Constraint dphone2_un Unique (d_phone)
, Constraint dlocation2_un Unique (d_name, d_city, d_state)
) Engine = Innodb;


/*  demo 25  */
Create Table a_testbed.ddl_emp_2 (
  e_id numeric(3)
, e_name varchar(15) Not Null
, d_id numeric(3)
, salary numeric(5)
  Default 30000
, hiredate date
, startsalary numeric(5)
, Constraint emp2_pk Primary Key (e_id)
, Constraint emp2_dept2_fk Foreign Key (d_id) References a_testbed.ddl_dept_2 (d_id)
) Engine = Innodb;


/*  demo 26  */
Drop Table a_testbed.ddl_dept;