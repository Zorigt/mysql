Use a_testbed;

/*  demo 01	  */
Delete from a_emp.employees where  emp_id = 1995;
Insert into a_emp.employees values 
   (1995,'Zahn', 'Joe', '111111111', 100, 10, '2009-09-09', 500, 2);

Delete from  a_prd.products  where  prod_id = 1995;
Insert into a_prd.products values
(1995, 'book','Train your cat book',29.95, 'PET', null);

/*  demo 02  */	
CREATE OR REPLACE VIEW vw_emp AS 
    Select emp_id, name_last, name_first 
    From a_emp.employees; 

Select name_first, name_last 
From a_emp.employees 
Where emp_id = 1995;

/*  demo 03  */
Update vw_emp 
Set name_first = 'Susan' 
Where emp_id = 1995;

Select name_first, name_last 
From a_emp.employees 
Where emp_id = 1995;


/*  demo 04  */	
Update vw_emp 
Set salary = 12500 
Where emp_id = 1995;


/*  demo 05  */	
Update vw_emp 
Set name_last = null
Where emp_id = 1995;

Delete from vw_emp 
Where emp_id = 1995;



/*  demo 06  */	
CREATE OR REPLACE VIEW vw_high_price_by_category AS
    Select catg_id, MAX(prod_list_price) As HighPrice
    From a_prd.products
    Group by catg_id;

/*  demo 07  */
Update vw_high_price_by_category
Set HighPrice = 250
Where catg_id = 'PET';


/*  demo 08  */
CREATE  VIEW vw_new_price AS
    Select catg_id, prod_name, Round(prod_list_price * 1.05,2) As NewPrice
    From a_prd.products;


/*  demo 09  */
Update vw_new_price 
Set NewPrice = 45 
Where prod_name like '%Cat%'


/*  demo 10  */
CREATE  VIEW vw_new_price_2 AS
    Select catg_id, prod_name, prod_list_price * 1 As NewPrice
    From a_prd.products;

Update vw_new_price_2 
Set NewPrice = 45 
Where prod_name like '%Cat%';

/*  demo 11	  */
CREATE OR REPLACE VIEW vw_em_dept_1 AS
    Select E.emp_id, E.name_last
    , E.dept_id
    , D.dept_name
    From a_emp.employees   E
    Join a_emp.departments D on  E.dept_id = D.dept_id;


/*  demo 12  */	
CREATE OR REPLACE VIEW vw_em_dept_2 AS
    Select E.emp_id, E.name_last
    , D.dept_id
    , D.dept_name
    From a_emp.employees   E
    Join a_emp.departments D on  E.dept_id = D.dept_id;

select * 
from vw_em_dept_2;

/*  demo 13  */
Update vw_em_dept_2
Set dept_id = 80
Where emp_id = 1995
;


/*  demo 14  */	
CREATE OR REPLACE VIEW product_list AS
    Select 
      prod_id + 0     as prod_id
    , prod_list_price as prod_list_price
    , concat(prod_name, '')  as prod_name
    , prod_desc 
    From a_prd.products;


/*  demo 15  */	
Update product_list 
Set prod_list_price = 15 
Where prod_id = 1995;


/*  demo 16  */	
Update product_list  
Set prod_name = 'Cats and me' 
Where prod_id = 1995;

/*  demo 17  */
CREATE OR REPLACE VIEW emp_dept_10 AS
    Select 
      emp_id
    , name_last
    , dept_id
    From a_emp.employees 
    Where dept_id = 10
WITH CHECK OPTION;



/*  demo 18  */
Update emp_dept_10
Set name_last = 'Hoyer'
Where emp_id = 1995;


/*  demo 19  */
Update emp_dept_10
Set dept_id = 20
Where emp_id = 1995;


/*  demo 20  */
CREATE OR REPLACE VIEW EmpHighSalary AS
    Select emp_id, name_last, salary, dept_id
    From a_emp.employees 
    Where salary > 70000
WITH CHECK OPTION;

select * 
from EmpHighSalary;

/*  demo 21  */
Update a_emp.employees  
Set name_last = 'Prince',
    salary = 75000
Where emp_id = 1995;

Select * 
From EmpHighSalary ;


/*  demo 22  */
Update EmpHighSalary 
Set name_last = 'Prince',
    salary = 85000
Where emp_id = 1995;



/*  demo 23  */
Update EmpHighSalary 
Set name_last = 'Koch',
    salary = 10000
Where emp_id = 1995;
;
