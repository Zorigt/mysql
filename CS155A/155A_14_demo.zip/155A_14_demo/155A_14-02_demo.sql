Use a_testbed;

/*  demo 01	  */
Drop Table If Exists a_testbed.ddl_alter;

Create Table a_testbed.ddl_alter (
  id integer Primary Key
);

Desc ddl_alter;


Alter Table a_testbed.ddl_alter
Add d_office varchar(10);
Desc ddl_alter;


Alter Table a_testbed.ddl_alter
Add Constraint office_un Unique (d_office);
Desc ddl_alter;


/*  demo 02  */	
Alter Table a_testbed.ddl_alter
Add (
  e_ssn char(11)
, e_namefirst varchar(20)
, e_salary numeric(6));

Desc a_testbed.ddl_alter;


/*  demo 03  */
Alter Table a_testbed.ddl_alter
Drop Column e_ssn;



/*  demo 04  */	
Alter Table a_testbed.ddl_alter
Drop Primary Key;

Desc a_testbed.ddl_alter;


/*  demo 05  */	
Alter Table a_testbed.ddl_alter
Modify e_namefirst varchar(25);


/*  demo 06  */	
Insert Into ddl_alter
  Values (101, 'sales', 'anastasia-marie', 500);

Alter Table a_testbed.ddl_alter
Modify e_namefirst varchar(10);


Desc a_testbed.ddl_alter;

/*  demo 07  */
Update a_testbed.ddl_alter
Set e_namefirst = 'sue';


Alter Table a_testbed.ddl_alter
Modify e_namefirst varchar(10);

Desc a_testbed.ddl_alter;



/*  demo 08  */
Alter Table a_testbed.ddl_alter
Modify e_salary float Not Null;

Desc a_testbed.ddl_alter;

/*  demo 09  */
Alter Table a_testbed.ddl_alter
Modify e_salary real;

Desc a_testbed.ddl_alter; 


/*  demo 10  invalid  */

Alter table a_testbed.ddl_alter
change e_namefirst varchar(30) not null;


Alter Table a_testbed.ddl_alter
Change e_namefirst e_namefirst varchar(30) Not Null;