Use a_testbed;

/*  demo 01  */
Drop Table If Exists a_testbed.ac_emp;
Drop Table If Exists a_testbed.ac_dept;

/*  demo 02  */
Create Table a_testbed.ac_dept (
  d_id numeric(3)
, Constraint ac_dept_pk Primary Key (d_id)
, d_name varchar(15) Not Null
, d_budget numeric(6) Null
, d_expenses_to_date numeric(6) Null
, d_city varchar(15) Not Null
, d_state char(2) Not Null
, Constraint ac_dlocation_un Unique (d_name, d_city, d_state)
) Engine = Innodb;


Create Table a_testbed.ac_emp (
  e_id numeric(3)
, e_name varchar(15) Not Null
, d_id numeric(3) Null
, salary numeric(5) Unsigned
  Default 30000 Null
, hiredate date Null
, e_status char(4) Null
, Constraint ac_emp_pk Primary Key (e_id)
, Constraint ac_emp_dept_fk Foreign Key (d_id) References a_testbed.ac_dept (d_id)
) Engine = Innodb;


/*  demo 03  */
Insert Into a_testbed.ac_dept (d_name, d_id, d_city, d_state, d_budget, d_expenses_to_date)
  Values ('FINANCE', 301, 'PEKIN', 'IL', 50000, 15000);

Insert Into a_testbed.ac_dept (d_id, d_budget, d_expenses_to_date, d_name, d_city, d_state)
  Values (501, 15000, 16000, 'SALES', 'RENO', 'NV');

/*  demo 04  */
Insert Into a_testbed.ac_dept
  Values (201, 'SALES', 35000, Null, 'CHICAGO', 'IL');

/*  demo 05  */
Insert Into a_testbed.ac_dept (d_name, d_id, d_city, d_state)
  Values ('ADMIN', 401, 'CHICAGO', 'IL');

/*  demo 06  */
Insert Into a_testbed.ac_emp (e_id, e_name, d_id, salary, hiredate, e_status)
  Values (10, 'FREUD', 301, Default, '2002-06-06', 'PERM');

/*  demo 07  */
Insert Into a_testbed.ac_emp (e_id, e_name, d_id, e_status)
  Values (20, 'MATSON', 201, 'PERM');


/*  demo 08  */		 
Insert Into a_testbed.ac_emp (e_id, e_name, d_id, salary, hiredate, e_status)
  Values (30, 'HANSON', 201, 40000, '2003-05-15', 'PERM')
  , (40, 'IBSEN', 201, 45000, '2003-05-20', 'PERM')
  , (50, 'MILES', 401, 25000, '2003-06-20', 'PERM')
  , (60, 'TANG', 401, 25000, '2003-06-20', Null)
  , (70, 'KREMER', 501, 50000, '2003-07-15', Null)
  , (80, 'PAERT', 201, 65000, '2003-07-18', Null)
  , (90, 'JARRET', 301, 60000, '2003-08-08', Null);

/*  demo 09  These inserts fail */
Insert Into a_testbed.ac_dept (d_name, d_id, d_city, d_state, d_budget)
  Values ('FINANCE', 304, Null, 'NY', 25000);
Insert Into a_testbed.ac_dept (d_name, d_id, d_city, d_state, d_budget)
  Values ('SALES', 305, 'CHICAGO', 'IL', 45000);

Insert Into a_testbed.ac_emp (e_id, e_name, d_id, e_status)
  Values (99, 'MATSON', 210, 'PERM');
Insert Into a_testbed.ac_emp (e_id, e_name, d_id, e_status)
  Values (98, 'Mathewsohn-Maryville', 201, 'PERM');

Select *
From a_testbed.ac_dept;


Select *
From a_testbed.ac_emp;

/*  demo 10  */
Insert Into a_testbed.ac_dept
Set d_name = 'Research'
, d_id = 800
, d_city = 'San Francisco'
, d_state = 'CA'
, d_budget = 98000;


/*  demo 11  */
Create Table a_testbed.ac_potentialhire (
  e_id numeric(3)
, e_name varchar(15) Not Null
, d_id numeric(3)
, salary numeric(5) Unsigned
, hiredate date
, e_status char(4)
) Engine = Innodb;

Truncate Table a_testbed.ac_potentialhire;


Insert Into a_testbed.ac_potentialhire (e_id, e_name, d_id, salary, hiredate, e_status)
  Values (201, 'ROBYN', 301, 20000, '2009-09-15', 'TEMP');
Insert Into a_testbed.ac_potentialhire (e_id, e_name, d_id, salary, hiredate, e_status)
  Values (202, 'ECHART', 201, 20000, Null, 'TEMP');
Insert Into a_testbed.ac_potentialhire (e_id, e_name, d_id, salary, hiredate, e_status)
  Values (203, 'TATUM', 301, 25000, '2009-09-18', 'TEMP');
  
/*  demo 12  */
Insert Into a_testbed.ac_emp (e_id, e_name, d_id, salary, hiredate, e_status)
  Select
    e_id
  , e_name
  , d_id
  , salary
  , hiredate
  , e_status
  From ac_potentialhire
  Where hiredate Is Not Null;

/*  demo 13  */
Delete
From a_testbed.ac_potentialhire
Where hiredate Is Not Null;

Select  *
From a_testbed.ac_emp;

Select  *
From a_testbed.ac_potentialhire;

/*  demo 14  */
Delete
From a_testbed.ac_emp
Where d_id = 601;

/*  demo 15  */
Delete
From a_testbed.ac_emp
Where d_id In (
    Select
      d_id
    From a_testbed.ac_dept
    Where d_state = 'NV'
  );

/*  demo 16  */
Update a_testbed.ac_emp
Set e_status = 'TEMP';

/*  demo 17  */
Update a_testbed.ac_emp
Set e_status = 'PERM'
Where hiredate < '2003-07-01';

/*  demo 18  */
Update a_testbed.ac_dept
Set d_city = 'SAN FRANCISCO'
  , d_state = 'CA'
Where d_id = 401;

/*  demo 19  */
Update a_testbed.ac_emp
Set salary = salary * 1.1
Where e_status = 'PERM';

/*  demo 20  */
Update a_testbed.ac_emp
Set salary = salary * (1 +
    Case
      When salary < 40000 Then 0.25
      When salary < 50000 Then 0.10 Else 0.05
    End);
    
    
/*  demo 21  */	
Update a_testbed.ac_emp
Set salary = salary * 1.1
Where d_id In (
  Select
    d_id
  From a_testbed.ac_dept
  Where d_state = 'CA'
);

/*  demo 22  */	
Select
  d_city
, d_state
, e_name
, salary
From a_testbed.ac_dept
Join a_testbed.ac_emp On ac_dept.d_id = ac_emp.d_id
Order By d_state, d_city;


Set @city = 'CHICAGO';
Set @state = 'IL';
Set @wageDifferential = 1.25;

Update a_testbed.ac_emp
Set salary = salary * @wageDifferential
Where d_id In (
  Select
    d_id
  From a_testbed.ac_dept
  Where d_state = @state
  And d_city = @city
);

Select
  d_city
, d_state
, e_name
, salary
From a_testbed.ac_dept
Join a_testbed.ac_emp On ac_dept.d_id = ac_emp.d_id
Order By d_state, d_city;

/*  demo 23  */	
Update a_testbed.ac_dept
Set d_budget = d_budget - d_expenses_to_date
  , d_expenses_to_date = Null;

Select
  d_id
, d_budget
, d_expenses_to_date
From a_testbed.ac_dept;

/*  demo 24  */

Update a_testbed.ac_dept
Set d_budget = Case
        When d_budget > COALESCE(d_expenses_to_date, 0) Then d_budget - COALESCE(d_expenses_to_date, 0) Else 0
      End
  , d_expenses_to_date = Case
        When d_budget > COALESCE(d_expenses_to_date, 0) Then 0 Else COALESCE(d_expenses_to_date, 0) - d_budget
      End
Where d_budget Is Not Null;

Select
  d_id
, d_budget
, d_expenses_to_date
From a_testbed.ac_dept;

/*  demo 25  */
Update a_testbed.ac_dept
Set d_budget = RAND() * COALESCE(d_budget, 500);

Select
  d_id
, d_budget
, d_expenses_to_date
From a_testbed.ac_dept;

/*  demo 26  */
Update a_testbed.ac_dept
Set d_budget = Null;

-- ------------------------------------------------------------
/*  demo 27  */
Create Table a_testbed.ac_emp_d201 As
   Select *
   From a_testbed.ac_emp
   Where d_id = 201;

Select *
From a_testbed.ac_emp_d201;

/*  demo 28  */
Create Table a_testbed.ac_emp_il As
Select
  e_name
, salary
, d_city
, d_state
From a_testbed.ac_dept
   , a_testbed.ac_emp
Where a_testbed.ac_dept.d_id = aa_testbed.c_emp.d_id
And d_state = 'IL';



/*  demo 29  */
Create Table a_testbed.ac_potentialhire_2 As
Select  *
From a_testbed.ac_emp
Where 1 = 2; 


 show create table a_testbed.ac_potentialhire_2;

