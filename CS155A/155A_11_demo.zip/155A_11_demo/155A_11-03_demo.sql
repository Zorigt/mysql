delimiter #
Use a_emp#

/*  Demo 01  */
Select  a_emp.newsalary_1 (4500) as Result #
Select  a_emp.newsalary_1 (null) as Result #
Select  a_emp.newsalary_1 (-4500) as Result #


/*  Demo 02  */	
Drop function if exists  a_emp.newsalary_1_V2#

create function  a_emp.newsalary_1_V2 (
   in_salary   decimal(9,2))
   returns decimal(10,2) 
begin
   declare  c_increase_amount decimal (8,2) default 300;
   declare  v_new_salary      decimal (8,2);

 
   if in_salary is null then
      set v_new_salary  := c_increase_amount;
   elseif in_salary < 0 then
      set v_new_salary  := 0;
   else
      set v_new_salary  := in_salary + c_increase_amount;
   end if;

   return v_new_salary ;
end;
#

/*  Demo 03  */	
Select 
  Salary
, AnticipatedValue
,  a_emp.newsalary_1_V2 (salary) as "new salary"
, AnticipatedValue -  a_emp.newsalary_1_v2(salary) as "problem"
from (
    Select 10000 as Salary
         , 10300 as AnticipatedValue 
  union all  
    Select null,   300
  union all  
    Select -500,  0
) as tstTbl#


Select 
    a_emp.newsalary_1_V2 (4500) as Result_1
,   a_emp.newsalary_1_V2 (null) as Result_2
,   a_emp.newsalary_1_V2 (-35)  as Result3#


/*  Demo 04  */	
drop function if exists a_testbed.FutureDate#

create  function a_testbed.FutureDate (
  p_date  datetime
, p_yr  int
, p_mn  int
, p_day  int)
  returns date
BEGIN
    declare return_date date ;
	set return_date := p_date;

    set p_yr  :=coalesce(p_yr,  0);
    set p_mn  :=coalesce(p_mn,  0);
    set p_day :=coalesce(p_day, 0);

    set return_date := date_add(return_date, interval p_yr year);
    set return_date := date_add(return_date, interval p_mn month);
    set return_date := date_add(return_date, interval p_day day);

    return return_date;
    end;
#


Select a_testbed.FutureDate(current_date,4,5,-2)#


/*  Demo 05  */
drop function if exists a_testbed.FutureDate2#


create function a_testbed.FutureDate2 (
  p_date  datetime
, p_y  int
, p_m  int
, p_d  int)
  returns date
BEGIN
 return p_date + interval coalesce(p_y, 0) year + interval coalesce(p_m, 0) month + interval coalesce(p_d, 0) day;
    end;
#
