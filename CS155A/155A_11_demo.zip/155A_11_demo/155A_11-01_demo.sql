Delimiter #

/*  Demo 01  */
	
Drop function if exists a_emp.Bonus_1#;

/*  Demo 02  */	
create FUNCTION a_emp.Bonus_1 (
   in_salary decimal(9,2) 
)
   RETURNS decimal(9,2)
BEGIN
/* local variable declaration */
   declare c_bonus_rate decimal(9,2);
   declare v_bonus decimal(9,2);
   set c_bonus_rate := 0.15;

   set v_bonus := round(in_salary * c_bonus_rate,2);
   RETURN v_bonus;
END;
#


/*  Demo 03  */	
select emp_id
,      salary
,      a_emp.Bonus_1(salary)
from   a_emp.employees
limit 4
#



/*  Demo 03  */	
select a_emp.Bonus_1(300), a_emp.Bonus_1(5000)#


 /*  Demo 05  */	
Select prod_id, prod_list_price, a_emp.Bonus_1(prod_list_price)+  prod_list_price as NewPrice
From a_prd.products
Limit 5;

/*  Demo 06   */	
Drop function if exists a_emp.newsalary_1 #

create function a_emp.newsalary_1 (
   in_salary   decimal (9,2))
   returns decimal (10,2) 
begin
  declare  c_increase_amount decimal (10,2) default 300;
  declare  v_new_salary      decimal (10,2);

  set v_new_salary  := in_salary + c_increase_amount;
   return v_new_salary ;
end;
#


/*  Demo 07  */	

select   emp_id, dept_id, hire_date, salary
,        a_emp.newsalary_1(salary) Sal_1  
from     a_emp.employees
limit 4
#

/*  Demo 08  */	
Drop function if exists a_emp.newsalary_2 #

create function a_emp.newsalary_2 (
   in_salary   decimal (10,2) ) 
   returns decimal (11,2)
begin
  declare  c_increase_rate decimal (4,2) default 0.05;
  declare  v_new_salary             decimal (11,2);

   set v_new_salary:= Round(in_salary *(1+ c_increase_rate),2);
   return v_new_salary ;

end;
#

/*  Demo 09  */	
Select
  emp_id
, dept_id
, hire_date
, salary
, a_emp.newsalary_2(salary) Sal_2
From a_emp.employees
Limit 4
#