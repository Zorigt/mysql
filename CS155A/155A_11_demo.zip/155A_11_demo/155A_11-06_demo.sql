Delimiter #
Use a_testbed#

Create table a_testbed.pets (
   pet_id    int primary key
,  pet_name  varchar(25) not null
,  pet_price numeric(6,2) not null
,  pet_added_date date not null
)
#
/*  Demo 01   */
drop procedure if exists a_testbed.insert_pet#

create procedure a_testbed.insert_pet ( 
     in_pet_id      int  
    ,in_pet_name   varchar(25)
    ,in_pet_price  numeric(6,2)
)
begin
   insert into a_testbed.pets (
               pet_id
            ,  pet_name  
            ,  pet_price 
            ,  pet_added_date)
    values(
               in_pet_id
            ,  in_pet_name  
            ,  in_pet_price 
            ,  curdate() );

end;
#

/*  Demo 02  */
Call a_testbed.insert_pet( 101, 'Mittens',  50)#
Call a_testbed.insert_pet( 105, 'Spot',  45.28)#
Call a_testbed.insert_pet( 108, 'Curley',  5000)#


Select * from a_testbed.pets#

/*  Demo 03  */
drop procedure if exists a_testbed.change_pet_price #

Create procedure a_testbed.change_pet_price (
     p_pet_ID int, p_price_change numeric(6,2))
begin 
   update   a_testbed.pets
      set   pet_price = pet_price + p_price_change
    where   pet_id = p_pet_id;
end;
#

/*  Demo 04  */
Set @pet_id = 105#
Set @pIncrease = 100#

/*  Demo 05  */
Call a_testbed.change_pet_price(@pet_id, @pIncrease) #

Select
  *
From a_testbed.pets #