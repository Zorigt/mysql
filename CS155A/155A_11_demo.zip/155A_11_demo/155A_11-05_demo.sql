delimiter #
Use a_emp#


/*  Demo 01  */

Drop function if exists a_emp.DeptEmployeeCount #

Create function a_emp.DeptEmployeeCount  (
   p_dept_id int)
   returns int
begin
    declare  v_row_count   int ;
    select   count(*)
    into     v_row_count
    from     a_emp.employees
    where    Dept_id = p_dept_id;
    
    return v_row_count;
end;
#
/*  Demo 02  */
Select a_emp.DeptEmployeeCount (80) #

Select a_emp.DeptEmployeeCount (1234) #


/*  Demo 03  */
Drop function if exists a_emp.empjobtitle# 

create function a_emp.empjobtitle
   (in_emp_id int) 
   returns varchar(100)
begin
   declare  v_job_title  varchar(35);
   declare  v_message    varchar(100);

   select   job_title
     into   v_job_title
     from   a_emp.employees join a_emp.jobs using (job_id)
     where  emp_id = in_emp_id;
   set  v_message := concat('employee ' , in_emp_id ,' has job ' , v_job_title);
   return v_message;
end; 
#

/*  Demo 04  */
Select a_emp.mpJobTitle(103) #


/*  Demo 05 */
Select a_emp.EmpJobTitle(63) #

/*  Demo 06 */
Select  coalesce(a_emp.EmpJobTitle(63), 'bad value for Employee id') as Result#


/*  Demo 07  */
Drop function if exists a_emp.empjobtitle_v2# 

create function a_emp.empjobtitle_v2
   (in_emp_id int) 
   returns varchar(100)
begin
   declare  v_job_title  varchar(35);
   declare  v_message    varchar(100);

   if NOT exists (
       select 1
       from a_emp.employees
       where emp_id = in_emp_id
        ) then
     set v_message := null;
   else
      select   job_title
     into   v_job_title
     from   a_emp.employees 
     join a_emp.jobs using (job_id)
     where  emp_id = in_emp_id;
     set  v_message := concat('employee ' , in_emp_id ,' has job ' , v_job_title);
   end if;
   return v_message;
end; 
#

/*  Demo 08 */
Select a_emp.EmpJobTitle_v2(63) #
Select  coalesce(a_emp.EmpJobTitle_v2(63), 'bad value for Employee id') as Result#