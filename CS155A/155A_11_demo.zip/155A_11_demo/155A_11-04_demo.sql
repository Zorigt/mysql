Delimiter #
Use a_testbed
/*  Demo 01  */
Show  create function a_emp.newsalary_6 \G

/*  Demo 02  */
delimiter ;
desc information_schema.routines;

/*  Demo 03  */
Select * 
from information_schema.routines 
where routine_name = 'newsalary_6'\G

/*  Demo 04  */
Select routine_definition
From information_schema.routines
Where routine_type = 'function'
and  routine_name = 'newsalary_6'
and routine_schema = 'a_emp';



/*  Demo 05  */
desc information_schema.parameters;

/*  Demo 06  */
Select
  parameter_name
, ordinal_position
, data_type
, parameter_mode
From information_schema.parameters
Where specific_name = 'newsalary_6'
and specific_schema = 'a_emp';


/*  Demo 07  */
Select
  specific_schema, specific_name
, parameter_name
, ordinal_position
, parameter_mode
From information_schema.parameters
Where data_type = 'date'
;



Select
  specific_schema, specific_name
, parameter_name
, ordinal_position
, parameter_mode
From information_schema.parameters
Where data_type = 'int'
And specific_schema = 'a_emp';
