
-- Demo 01:	
Select
  dept_id
, SUM(salary)
, COUNT(salary)
, COUNT(emp_id)
From a_emp.adv_emp
Group By dept_id;

-- Demo 02:	
Select
  dept_id
, SUM(salary)
, COUNT(salary)
, COUNT(emp_id)
From a_emp.adv_emp
Group By dept_id With Rollup
;

-- Demo 03:	
Select
  CONCAT("dept: ", COALESCE(dept_id, 'All')) As Dept
, SUM(salary)
, COUNT(salary)
, COUNT(emp_id)
From a_emp.adv_emp
Group By dept_id With Rollup
;

-- Demo 04:	
Select
  CONCAT("dept: ", dept_id) As dept
, SUM(salary)
, COUNT(salary)
, COUNT(emp_id)
From a_emp.adv_emp
Group By dept_id
Union
Select
  "dept: All"
, SUM(salary)
, COUNT(salary)
, COUNT(emp_id)
From a_emp.adv_emp
;

-- Demo 05:	
Select
  salary
, COUNT(emp_id)
From a_emp.adv_emp
Group By salary With Rollup
;
Select
  COALESCE(salary, 'all') As salary
, COUNT(emp_id)
From a_emp.adv_emp
Group By salary With Rollup
;
Select
  COALESCE(LPAD(salary, 12, ' '), 'All Salaries') As salary
, COUNT(emp_id)
From a_emp.adv_emp
Group By salary With Rollup
;

-- Demo 06:	
Select
  TRUNCATE(salary, - 4)
, emp_id
From a_emp.adv_emp
;

-- Demo 07
Select
  salary_10K
, COUNT(emp_id) As NumbrEmp
From (
  Select
    TRUNCATE(salary, - 4) As salary_10K
  , emp_id
  From a_emp.adv_emp
) tbl_trunc
Group By salary_10K With Rollup;

-- Demo 08
Select
  salary_10K
, NumbrEmp
From (
  Select
    salary_10K
  , COUNT(emp_id) As NumbrEmp
  From (
    Select
      TRUNCATE(salary, - 4) As salary_10K
    , emp_id
    From a_emp.adv_emp
  ) tbl_trunc
  Group By salary_10K With Rollup
) rolled;

-- Demo 09
Select
    Case
      When salary_10K Is Null Then '    Total'
      When salary_10K = 0 Then 'Under 10K' Else LPAD(FORMAT(salary_10K, 0), 9, ' ')
    End As salary_10K
  , NumbrEmp
From (
  Select
    salary_10K
  , COUNT(emp_id) As NumbrEmp
  From (
    Select
      TRUNCATE(salary, - 4) As salary_10K
    , emp_id
    From a_emp.adv_emp
  ) tbl_trunc
  Group By salary_10K With Rollup
) rolled;

-- Demo 10	  
Select
  dept_id
, year_hired
, SUM(salary)
, COUNT(salary)
, COUNT(emp_id)
From a_emp.adv_emp
Group By dept_id, year_hired With Rollup
;

-- Demo 11:	
Select
  cust_id
, ord_id
, SUM(quantity_ordered * quoted_price) As AmntDue
, SUM(quantity_ordered) As NumberItems
From a_oe.order_headers
Join a_oe.order_details Using (ord_id)
Where ord_date Between '2012-02-01' And '2012-02-28'
Group By cust_id, ord_id;

-- Demo 12:	
Select
  cust_id
, ord_id
, SUM(quantity_ordered * quoted_price) As AmntDue
, SUM(quantity_ordered) As NumberItems
From a_oe.order_headers
Join a_oe.order_details Using (ord_id)
Where ord_date Between '2012-02-01' And '2012-02-28'
Group By cust_id, ord_id With Rollup
;
-- Demo 12b- not so good:	
Select
  cust_id
, ord_id
, SUM(quantity_ordered * quoted_price) As AmntDue
, SUM(quantity_ordered) As NumberItems
From a_oe.order_headers
Join a_oe.order_details Using (ord_id)
Where ord_date Between '2012-02-01' And '2012-02-28'
Group By ord_id With Rollup
;
-- Demo 12 c better:	
Select
    Case
      When ord_id Is Null Then 'Total' Else cust_id
    End As Customer
  , COALESCE(ord_id, 'Total') As order_id
  , AmntDue
  , NumberItems
From (
  Select
    cust_id
  , ord_id
  , SUM(quantity_ordered * quoted_price) As AmntDue
  , SUM(quantity_ordered) As NumberItems
  From a_oe.order_headers
  Join a_oe.order_details Using (ord_id)
  Where ord_date Between '2012-02-01' And '2012-02-28'
  Group By ord_id With Rollup
) calc
;

-- demo 13
Select
  COALESCE(cust_id, 'Grand Total') As CustID
, Case
      When cust_id Is Null Then ' ' Else COALESCE(ord_id, 'Cust Total')
    End As OrderID
, AmntDue
, NumberItems
From (
  Select
    cust_id
  , ord_id
  , SUM(quantity_ordered * quoted_price) As AmntDue
  , SUM(quantity_ordered) As NumberItems
  From a_oe.order_headers
  Join a_oe.order_details Using (ord_id)
  Where ord_date Between '2012-02-01' And '2012-02-28'
  Group By cust_id, ord_id With Rollup
) tbl
;

-- Demo 14	
Select
  cust_id
, ord_id
, SUM(quantity_ordered * quoted_price) As AmntDue
, SUM(quantity_ordered) As NumberItems
From a_oe.order_headers
Join a_oe.order_details Using (ord_id)
Where ord_date Between '2012-02-01' And '2012-02-28'
Group By ord_id, cust_id With Rollup
;

-- Demo 15:	
Select
  YEAR(ord_date)
, MONTH(ord_date)
, ord_id
, SUM(quantity_ordered * quoted_price) As amntdue
, SUM(quantity_ordered) As NumberItems
From a_oe.order_headers
Join a_oe.order_details Using (ord_id)
Group By YEAR(ord_date), MONTH(ord_date), ord_id With Rollup;


-- Demo 16:	
Select
  YEAR(ord_date)
, MONTH(ord_date)
, ord_id
, SUM(quantity_ordered * quoted_price) As amntdue
, SUM(quantity_ordered) As NumberItems
From a_oe.order_headers
Join a_oe.order_details Using (ord_id)
Group By YEAR(ord_date), MONTH(ord_date), ord_id With Rollup
Having ord_id Is Null;