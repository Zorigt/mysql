
-- Demo 01:	
Set @running_total = 0;

Select
  emp_id
, dept_id
, salary
, @running_total := @running_total + salary As RunningTotal
From a_emp.adv_emp
Order By dept_id, emp_id;

-- Demo 02	
Set @accum = 0;

Select
  emp_id
, dept_id
, salary
, @accum := @accum + salary As RunningTotal
From a_emp.adv_emp
Order By salary, emp_id;



-- Demo 03:
Set @total := 0;
Select
  dept_id
, DeptTotal
, @total := @total + DeptTotal As RunningTotal
From (
  Select
    dept_id
  , SUM(salary) As DeptTotal
  From a_emp.adv_emp
  Group By dept_id
) dt
Order By dept_id;


-- Demo 04:	
Select
  emp_1.emp_id
, emp_1.salary
, SUM(emp_2.salary) As RunningTotal
From a_emp.adv_emp emp_1
Join a_emp.adv_emp emp_2 On emp_2.emp_id <= emp_1.emp_id
Group By emp_1.emp_id
Order By emp_1.emp_id;

-- Demo 05:	
Select
  emp_1.emp_id
, emp_1.salary
, (
    Select
      SUM(emp_2.salary)
    From a_emp.adv_emp As Emp_2
    Where emp_2.emp_id <= emp_1.emp_id
  ) As RunningTotal
From a_emp.adv_emp emp_1
Group By emp_1.emp_id
Order By emp_1.emp_id;


-- ----------------------
Select
  dt_1.dept_id
, dt_1.DeptTotal
, SUM(dt_2.DeptTotal) As RunningTotal
From (
  Select
    dept_id
  , SUM(salary) As DeptTotal
  From a_emp.adv_emp
  Group By dept_id
) dt_1
Join (
  Select
    dept_id
  , SUM(salary) As DeptTotal
  From a_emp.adv_emp
  Group By dept_id
) dt_2 On dt_2.dept_id <= dt_1.dept_id
Group By dt_1.dept_id
Order By dt_1.dept_id;



-- Demo 06:	
Select
  *
From adv_sales
Limit 10;

Select
  a1.sales_day
, a1.sales
, SUM(a2.sales) As three_day_sum
From adv_sales a1
Join adv_sales a2 On a2.sales_day Between a1.sales_day And DATE_ADD(a1.sales_day, Interval 2 Day)
Group By a1.sales_day, a1.sales
Order By a1.sales_day;

-- Demo 07:	
Select
  a1.sales_day
, a1.sales
, SUM(a2.sales) As three_day_sum
From adv_sales a1
Join adv_sales a2 On a2.sales_day Between a1.sales_day And DATE_ADD(a1.sales_day, Interval 2 Day)
And a1.sales_day <= (
  Select
    DATE_ADD(MAX(a3.sales_day), Interval - 2 Day)
  From adv_sales a3
)
Group By a1.sales_day, a1.sales
Order By a1.sales_day;
-- demo 08
Select
  a1.sales_day
, a1.sales
, SUM(a2.sales) As three_day_sum
From adv_sales a1
Join adv_sales a2 On a2.sales_day Between a1.sales_day And DATE_ADD(a1.sales_day, Interval 2 Day)
And a1.sales_day <= (
  Select
    DATE_ADD(MAX(a3.sales_day), Interval - 2 Day)
  From adv_sales a3
)
Where MONTH(a1.sales_day) = 4
And YEAR(a1.sales_day) = 2011
Group By a1.sales_day, a1.sales
Order By a1.sales_day;