
-- Demo 01:	
Set @rownum := 0;

Select
  emp_id
, dept_id
, salary
, @rownum := @rownum + 1 As Ranking
From a_emp.adv_emp
Order By salary
;


-- Demo 02:	
Set @salarynum := 0;

Select
  *
From (
  Select
    emp_id
  , salary
  , year_hired
  , @salarynum := @salarynum + 1 As RowNumber
  From a_emp.adv_emp
  Order By salary
) tbl
Order By year_hired Desc;


-- Demo 03:	
Set @dept := 0;
Set @rank := 0;
Select
  Dept_id
, Emp_id
, Salary
, Rank
From (
  Select
    Dept_id
  , Emp_id
  , Salary
  , Case
        When @dept = dept_id Then @rank := @rank + 1 Else @rank := 1
      End As Rank
  , Case
        When @dept <> dept_id Then @dept := dept_id
      End As Brk
  From a_emp.adv_emp
  Order By dept_id, salary
) tbl;


-- Demo 04:	
Select
  Emp_1.emp_id
, dept_id
, Emp_1.salary
, (
    Select
      COUNT(Distinct salary)
    From a_emp.adv_emp As Emp_2
    Where Emp_2.salary >= Emp_1.salary
    And dept_id = 30
  ) As Ranking
From a_emp.adv_emp As Emp_1
Where dept_id = 30
Order By ranking
;


-- Demo 05:	
Select
  Emp_1.emp_id
, dept_id
, Emp_1.salary
, (
    Select
      COUNT(Distinct salary)
    From a_emp.adv_emp As Emp_2
    Where Emp_2.salary > Emp_1.salary
    And dept_id = 30
  ) As Ranking
From a_emp.adv_emp As Emp_1
Where dept_id = 30
Order By ranking;


-- Demo 06:	
Select
  Emp_1.emp_id
, dept_id
, Emp_1.salary
, (
    Select
      COUNT(Distinct salary)
    From a_emp.adv_emp As Emp_2
    Where Emp_2.salary >= Emp_1.salary
    And dept_id = 30
  ) As Ranking1
, (
    Select
      COUNT(salary)
    From a_emp.adv_emp As Emp_2
    Where Emp_2.salary >= Emp_1.salary
    And dept_id = 30
  ) As Ranking2
From a_emp.adv_emp As Emp_1
Where dept_id = 30
Order By ranking1
;


-- Demo 07:	
Select
  Emp_1.emp_id
, dept_id
, Emp_1.salary
, (
    Select
      COUNT(salary)
    From a_emp.adv_emp As Emp_2
    Where Emp_2.salary > Emp_1.salary
    And dept_id = 30
  ) + 1 As Ranking2
From a_emp.adv_emp As Emp_1
Where dept_id = 30
Order By ranking2
;


-- Demo 08:	
select 
group_concat(salary order by salary desc)  as salarylist 
from a_emp.adv_emp;

-- demo 09
select 
group_concat(distinct salary order by salary desc)  as salarylist 
from a_emp.adv_emp;

-- demo 10
Select
  emp_id
, salary
, FIND_IN_SET(
  salary
  , (
    Select
      GROUP_CONCAT(Distinct salary Order By salary Desc)
    From a_emp.adv_emp
  )) As rank
From a_emp.adv_emp
Order By rank;

-- demo 11
Select
  emp_id
, salary
, FIND_IN_SET(
  salary
  , (
    Select
      GROUP_CONCAT(salary Order By salary Desc)
    From a_emp.adv_emp
  )) As rank
From a_emp.adv_emp
Order By rank
;