Use a_emp;

-- Demo 01:	
Select
  emp_id
, name_last
, mng
, dept_id
, year_hired
, salary
From a_emp.adv_emp
Order By dept_id, emp_id;


-- demo 02
Select
  dept_id
, SUM(salary)
, AVG(salary)
From a_emp.adv_emp
Group By dept_id
Order By dept_id;


-- demo 03
Select Avg(salary) 
from a_emp.adv_emp 
where dept_id = 215;

-- demo 04		  
Select
  emp_id
, salary
, salary - (
    Select
      AVG(salary)
    From a_emp.adv_emp
    Where dept_id = 215
  ) As Over_under_avg
From a_emp.adv_emp
Where dept_id = 215
;

-- demo 05
Set @avgsal = (
  Select
    AVG(salary)
  From a_emp.adv_emp
  Where dept_id = 215
);

Select
  emp_id
, salary
, salary - @avgsal As Over_under_avg
From a_emp.adv_emp
Where dept_id = 215
;
-- demo 06  
Select
  emp_id
, salary
, (salary - AvgDept215) As Over_under_avg
From a_emp.adv_emp
Cross Join (
  Select
    AVG(salary) As AvgDept215
  From a_emp.adv_emp
  Where dept_id = 215
) avgSal
Where dept_id = 215;



-- demo 07
Select
  emp_id
, dept_id
, salary
, salary - (
    Select
      AVG(salary)
    From a_emp.adv_emp
  ) As Over_under_avg
From a_emp.adv_emp
Order By dept_id, salary;

Select
  AVG(salary)
From a_emp.adv_emp;


-- demo 08
Select
  dept_id
, emp_id
, salary
, salary - (
    Select
      AVG(salary)
    From a_emp.adv_emp
    Where dept_id = OTR.dept_id
  ) As Over_under_avg
From a_emp.adv_emp OTR
Order By dept_id, salary;


-- demo 09
Select
  EmpLevel.dept_id
, emp_id
, salary
, salary - avgSalary
From a_emp.adv_emp As EmpLevel
Join (
  Select
    dept_id
  , AVG(salary) As avgSalary
  From a_emp.adv_emp
  Group By dept_id
) As DeptLevel On EmpLevel.dept_id = DeptLevel.dept_Id
Order By dept_id, salary;



-- demo 10
Select
  dept_id
, emp_id
, salary
, salary / (
    Select
      SUM(salary)
    From a_emp.adv_emp
    Where dept_id = OTR.dept_id
  ) As Over_under_avg
From a_emp.adv_emp OTR
Order By dept_id, salary;


-- demo 11
Select
  dept_id
, emp_id
, salary
, ROUND(100 * salary / (
    Select
      SUM(salary)
    From a_emp.adv_emp
    Where dept_id = OTR.dept_id
  ), 0
  ) As Percent
From a_emp.adv_emp OTR
Order By dept_id, salary;


-- demo 12
Select
  EmpLevel.dept_id
, emp_id
, salary
, TotDeptSalary
, ROUND(100 * salary / totDeptSalary, 0) As PercOfDept
From a_emp.adv_emp As EmpLevel
Join (
  Select
    dept_id
  , SUM(salary) As TotDeptSalary
  From a_emp.adv_emp
  Group By dept_id
) As DeptLevel On EmpLevel.dept_id = DeptLevel.dept_Id
Order By EmpLevel.dept_id, EmpLevel.salary;

