Use a_emp;
-- (1) initial simpler demo for aggregate
Select
  OH.Cust_ID As "CustID"
, OH.ord_Id As "OrdID"
, CAST(OH.Ord_Date As date) As "OrdDate"
, SUM(OD.quoted_price * OD.quantity_ordered) As "OrdTotal"
From a_oe.order_headers OH
Join a_oe.order_details OD On OH.ord_id = OD.ord_id
Where YEAR(ord_Date) = 2012
And MONTH(Ord_date) Between 1 And 6
Group By OH.Cust_ID, OH.ord_Id, OH.ord_date
Order By OH.Cust_ID, OH.ord_Id Desc;



-- (2) CREATE THIS VIEW
-- This gives total sales for each order
Create Or Replace View oe_cust_sales
As (
  Select
    OH.ord_id As ordID
  , CAST(OH.ord_date As date) As ordDate
  , OH.cust_id As CustID
  , SUM(OD.quoted_price * OD.quantity_ordered) As ordTotal
  From a_oe.order_headers OH
  Join a_oe.order_details OD On OH.ord_id = OD.ord_id
  Where OD.quoted_price > 0
  And OD.quantity_ordered > 0
  Group By OH.ord_id, OH.cust_id, OH.ord_date
);

-- (3) this uses subqueries for  the above logic
Select
  CS1.CustID
, CS1.ordId
, CS1.OrdDate
, CS1.OrdTotal

, (
    Select
      SUM(CS2.ordTotal)
    From a_oe_cust_sales CS2
    Where CS1.CustID = CS2.custid
    And YEAR(CS2.ordDate) = 2012
    And MONTH(CS2.Orddate) Between 1 And 6
  ) As CustTotal

, CAST(100 * ordTotal / (
    Select
      SUM(CS3.ordTotal)
    From a_oe_cust_sales CS3
    Where CS1.CustID = CS3.custid
    And YEAR(CS3.ordDate) = 2012
    And MONTH(CS3.Orddate) Between 1 And 6
  ) As decimal(12, 1)) As "%CustTotal"

, CAST(OrdTotal - (
    Select
      AVG(CS4.ordTotal)
    From a_oe_cust_sales CS4
    Where CS1.CustID = CS4.custid
    And YEAR(CS4.ordDate) = 2012
    And MONTH(CS4.Orddate) Between 1 And 6
  ) As decimal(12, 2)) As OverUnderAvgCust

, CAST(100 * ordTotal / (
    Select
      SUM(CS5.ordTotal)
    From a_oe_cust_sales CS5
    Where YEAR(CS5.ordDate) = 2012
    And MONTH(CS5.Orddate) Between 1 And 6
  ) As decimal(12, 1)) As "%AllTotal"

From a_oe_cust_sales CS1
Where YEAR(CS1.ordDate) = 2012
And MONTH(CS1.Orddate) Between 1 And 6
Order By CS1.CustID, CS1.ordId Desc;


-- (4) CREATE THIS VIEW
Create Or Replace View adv_emp
As (
  Select
    emp_id
  , name_last
  , emp_mng As mng
  , dept_id
  , YEAR(hire_date) As year_hired
  , CAST(COALESCE(salary, 0) As Signed integer) As salary
  From a_emp.employees
);


-- (5) CREATE THIS TABLE
Create Table a_oe.adv_sales (
  sales_day date Primary Key
, sales integer Not Null Check (sales >= 0)
); 

-- demo 03
--  The sales table inserts for analytical queries

Truncate table adv_sales;
Insert Into adv_sales
  Values ('2011-04-25', 400);
Insert Into adv_sales
  Values ('2011-04-26', 400);
Insert Into adv_sales
  Values ('2011-04-27', 400);
Insert Into adv_sales
  Values ('2011-04-28', 300);
Insert Into adv_sales
  Values ('2011-04-29', 900);
Insert Into adv_sales
  Values ('2011-04-30', 580);
Insert Into adv_sales
  Values ('2011-05-01', 425);
Insert Into adv_sales
  Values ('2011-05-02', 010);
Insert Into adv_sales
  Values ('2011-05-03', 325);
Insert Into adv_sales
  Values ('2011-05-04', 500);
Insert Into adv_sales
  Values ('2011-05-05', 550);
Insert Into adv_sales
  Values ('2011-05-06', 000);
Insert Into adv_sales
  Values ('2011-05-07', 000);
Insert Into adv_sales
  Values ('2011-05-08', 200);
Insert Into adv_sales
  Values ('2011-05-09', 450);
Insert Into adv_sales
  Values ('2011-05-10', 580);
Insert Into adv_sales
  Values ('2011-05-11', 425);
Insert Into adv_sales
  Values ('2011-05-12', 475);
Insert Into adv_sales
  Values ('2011-05-13', 375);
Insert Into adv_sales
  Values ('2011-05-14', 500);
Insert Into adv_sales
  Values ('2011-05-15', 650);
Insert Into adv_sales
  Values ('2011-05-16', 550);
Insert Into adv_sales
  Values ('2011-05-17', 450);
Insert Into adv_sales
  Values ('2011-05-18', 500);
Insert Into adv_sales
  Values ('2011-05-19', 575);
Insert Into adv_sales
  Values ('2011-05-20', 450);
Insert Into adv_sales
  Values ('2011-05-21', 500);
Insert Into adv_sales
  Values ('2011-05-22', 575);
Insert Into adv_sales
  Values ('2011-05-23', 850);
Insert Into adv_sales
  Values ('2011-05-24', 500);
Insert Into adv_sales
  Values ('2011-05-25', 575);
Insert Into adv_sales
  Values ('2011-05-26', 500);
Insert Into adv_sales
  Values ('2011-05-27', 575);
Insert Into adv_sales
  Values ('2011-05-28', 500);
Insert Into adv_sales
  Values ('2011-05-29', 575);
Insert Into adv_sales
  Values ('2011-05-30', 575);
Insert Into adv_sales
  Values ('2011-05-31', 575);


Select
  ord_date
, CAST(COALESCE(SUM(quantity_ordered * quoted_price), 0) As Signed integer) As sales
From a_oe.order_headers OH
Join a_oe.order_details OD On OH.ord_id = OD.ord_id
Group By ord_date;