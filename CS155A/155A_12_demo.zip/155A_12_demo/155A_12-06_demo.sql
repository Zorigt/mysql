-- demo 01
Create Table tblbook (
  bookid int
, title varchar(25)
);

Create Table tbltopic (
  bookid int
, topic varchar(15)
);

Insert Into tblbook
  Values (1, 'SQL for Fun and Profit'), (2, 'Gibson''s History');
Insert Into tbltopic
  Values (1, 'SQL'), (1, 'Bus'), (2, 'History');


Select
  bookid
, title
, topic
From tblbook
Join tbltopic Using (bookid);


Select
  tblbook.bookid
, title
, topic
From tblbook
Cross Join tbltopic;


Drop Table tblbook;
Drop Table tbltopic;


-- demo 02
select 0 as digit union  select 1 union  select 2 union  select 3 union  select 4 
union  select 5 union  select 6 union  select 7 union  select 8 union  select 9;

-- demo 03
Select
  *
From (
  Select
    0 As digit
  Union
  Select
    1
  Union
  Select
    2
  Union
  Select
    3
  Union
  Select
    4
  Union
  Select
    5
  Union
  Select
    6
  Union
  Select
    7
  Union
  Select
    8
  Union
  Select
    9
) Ones
Cross Join (
  Select
    0 As digit
  Union
  Select
    1
  Union
  Select
    2
  Union
  Select
    3
  Union
  Select
    4
  Union
  Select
    5
  Union
  Select
    6
  Union
  Select
    7
  Union
  Select
    8
  Union
  Select
    9
) Tens;


-- demo 04
Select
  Ones.digit + 10 * Tens.digit
From (
  Select
    0 As digit
  Union
  Select
    1
  Union
  Select
    2
  Union
  Select
    3
  Union
  Select
    4
  Union
  Select
    5
  Union
  Select
    6
  Union
  Select
    7
  Union
  Select
    8
  Union
  Select
    9
) Ones
Cross Join (
  Select
    0 As digit
  Union
  Select
    1
  Union
  Select
    2
  Union
  Select
    3
  Union
  Select
    4
  Union
  Select
    5
  Union
  Select
    6
  Union
  Select
    7
  Union
  Select
    8
  Union
  Select
    9
) Tens;


-- demo 05
Select
  0 val
Union
Select
  1;
Select
  0 val
Union
Select
  2;
Select
  0 val
Union
Select
  4;
Select
  0 val
Union
Select
  8;
Select
  0 val
Union
Select
  16;
Select
  0 val
Union
Select
  32;


-- demo 06
Select
  *
From (
  Select
    0 val
  Union All
  Select
    1
) b1
Cross Join (
  Select
    0 val
  Union All
  Select
    2
) b2
Cross Join (
  Select
    0 val
  Union All
  Select
    4
) b4
Cross Join (
  Select
    0 val
  Union All
  Select
    8
) b8
Cross Join (
  Select
    0 val
  Union All
  Select
    16
) b16
Cross Join (
  Select
    0 val
  Union All
  Select
    32
) b32
;


-- demo 07
Select
  b1.val + b2.val + b4.val + b8.val + b16.val + b32.val
From (
  Select
    0 val
  Union All
  Select
    1
) b1
Cross Join (
  Select
    0 val
  Union All
  Select
    2
) b2
Cross Join (
  Select
    0 val
  Union All
  Select
    4
) b4
Cross Join (
  Select
    0 val
  Union All
  Select
    8
) b8
Cross Join (
  Select
    0 val
  Union All
  Select
    16
) b16
Cross Join (
  Select
    0 val
  Union All
  Select
    32
) b32
;

-- demo 08
Create Table nums (
  value int
);

Insert Into nums
  Select
    Ones.digit + 10 * Tens.digit
  From (
    Select
      0 As digit
    Union
    Select
      1
    Union
    Select
      2
    Union
    Select
      3
    Union
    Select
      4
    Union
    Select
      5
    Union
    Select
      6
    Union
    Select
      7
    Union
    Select
      8
    Union
    Select
      9
  ) Ones
  Cross Join (
    Select
      0 As digit
    Union
    Select
      1
    Union
    Select
      2
    Union
    Select
      3
    Union
    Select
      4
    Union
    Select
      5
    Union
    Select
      6
    Union
    Select
      7
    Union
    Select
      8
    Union
    Select
      9
  ) Tens
;

-- demo 09
Select
  NumValue
, CONCAT('Unit: ', NumValue) As Units
From (
  Select
    b1.val + b2.val + b4.val + b8.val + b16.val As NumValue
  From (
    Select
      0 val
    Union All
    Select
      1
  ) b1
  Cross Join (
    Select
      0 val
    Union All
    Select
      2
  ) b2
  Cross Join (
    Select
      0 val
    Union All
    Select
      4
  ) b4
  Cross Join (
    Select
      0 val
    Union All
    Select
      8
  ) b8
  Cross Join (
    Select
      0 val
    Union All
    Select
      16
  ) b16
) As GenNum
Where NumValue Between 1 And 18
;

-- demo 10
Set @startdtm := '2012-08-15';
Set @stopdtm := '2012-12-19';

Select
  semesterdate
From (
  Select
    numvalue
  , ADDDATE(@startdtm, numvalue) As semesterdate
  From (
    Select
      b1.val + b2.val + b4.val + b8.val + b16.val + b32.val
      + b64.val + b128.val As numvalue
    From (
      Select
        0 val
      Union All
      Select
        1
    ) b1
    Cross Join (
      Select
        0 val
      Union All
      Select
        2
    ) b2
    Cross Join (
      Select
        0 val
      Union All
      Select
        4
    ) b4
    Cross Join (
      Select
        0 val
      Union All
      Select
        8
    ) b8
    Cross Join (
      Select
        0 val
      Union All
      Select
        16
    ) b16
    Cross Join (
      Select
        0 val
      Union All
      Select
        32
    ) b32
    Cross Join (
      Select
        0 val
      Union All
      Select
        64
    ) b64
    Cross Join (
      Select
        0 val
      Union All
      Select
        128
    ) b128
  ) As gennum
) As calendar
Where semesterdate Between @startdtm And @stopdtm
;


-- demo 11
Set @startdtm := '2012-08-15';
Set @stopdtm := '2012-12-19';


Select
  semesterdate
From (
  Select
    numvalue
  , ADDDATE(@startdtm, numvalue) As semesterdate
  From (
    Select
      b1.val + b2.val + b4.val + b8.val + b16.val + b32.val
      + b64.val + b128.val As numvalue
    From (
      Select
        0 val
      Union All
      Select
        1
    ) b1
    Cross Join (
      Select
        0 val
      Union All
      Select
        2
    ) b2
    Cross Join (
      Select
        0 val
      Union All
      Select
        4
    ) b4
    Cross Join (
      Select
        0 val
      Union All
      Select
        8
    ) b8
    Cross Join (
      Select
        0 val
      Union All
      Select
        16
    ) b16
    Cross Join (
      Select
        0 val
      Union All
      Select
        32
    ) b32
    Cross Join (
      Select
        0 val
      Union All
      Select
        64
    ) b64
    Cross Join (
      Select
        0 val
      Union All
      Select
        128
    ) b128
  ) As gennum
) As calendar
Where semesterdate Between @startdtm And @stopdtm
And DAYNAME(semesterdate) In ('Sunday', 'Saturday')
;


-- demo 12
Select Distinct
  ord_date
From a_oe.order_headers
Where YEAR(ord_date) = 2011
And MONTH(ord_date) = 12;

-- demo 13
-- calendar for dec 2011
Set @startdtm := '2011-12-01';
Set @stopdtm := '2011-12-31';

Select
  theDate As NoSalesDates
From (
  Select
    ADDDATE(@startdtm, numvalue) As theDate
  From (
    Select
      b1.val + b2.val + b4.val + b8.val + b16.val + b32.val As numvalue
    From (
      Select
        0 val
      Union All
      Select
        1
    ) b1
    Cross Join (
      Select
        0 val
      Union All
      Select
        2
    ) b2
    Cross Join (
      Select
        0 val
      Union All
      Select
        4
    ) b4
    Cross Join (
      Select
        0 val
      Union All
      Select
        8
    ) b8
    Cross Join (
      Select
        0 val
      Union All
      Select
        16
    ) b16
    Cross Join (
      Select
        0 val
      Union All
      Select
        32
    ) b32
  ) As gennum
) calendar
Where theDate Between @startdtm And @stopdtm
And theDate Not In (
  Select
    ord_date
  From a_oe.order_headers
);