Use a_testbed;

-- Demo 01	
Select
  A
, GREATEST(B, C, D, E, F)
, LEAST(B, C, D, E, F)
From a_testbed.z_tst_numbers;

-- Demo 02	
Select
  greatest(4, 45.78, 9);

-- Demo 03
Select
  greatest('p', 4, 45.78, 9);

-- Demo 04	
Select
  LEAST('p', 4, 45.78, 9);

-- Demo 05:	
Select
  ord_id
, prod_id
, quoted_price
, prod_list_price
From a_oe.order_details
Join a_prd.products Using (prod_id)
Where GREATEST(quoted_price, prod_list_price) > (prod_list_price)
;

-- Demo 06
Select
  IF(CURDATE() > '1888-08-08', 'passed the test', 'this is really old');

Select
  IF(MONTH(CURDATE()) In (6, 7, 8), 'Summer!', 'Not summer');

Select
  IF(5 > Null, 'passed the test', 'nulls make unknown values');

-- Demo 07
Select
  catg_id
, prod_id
, prod_list_price
, IF(catg_id In ('PET', 'SPG'), 0.95, 1) As "Price Multiplier"
From a_prd.products products
Order By prod_id
;

-- Demo 08
Select
  catg_id
, prod_id
, prod_list_price
, IF(catg_id In ('PET', 'SPG'), 0.95, IF(catg_id In ('APL'), 0.90, 1)
  ) As "Price Multiplier"
From a_prd.products products
Order By prod_id
;