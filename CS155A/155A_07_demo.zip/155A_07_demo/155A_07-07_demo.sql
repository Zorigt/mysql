Use a_prd;

-- Demo 01	
Select
  catg_id
, prod_id
, prod_list_price
, Case
      When catg_id = 'PET' Then 0.95
      When catg_id = 'SPG' Then 0.95
      When catg_id = 'APL' Then 0.90 Else 1
    End As "Price Multiplier"
From a_prd.products
Order By catg_id
;


-- Demo 02	
Select
  catg_id
, prod_id
, prod_list_price
, Case
      When catg_id = 'PET' Then 0.95
      When catg_id = 'SPG' Then 0.95
      When catg_id = 'APL' Then 0.90 Else 1
    End * prod_list_price As "Today's Price"
From a_prd.products
Order By catg_id
;


-- Demo 03
Select
  catg_id
, prod_id
, prod_list_price
, Case
      When catg_id = 'PET' Then 0.95
      When catg_id = 'SPG' Then 0.95
      When catg_id = 'APL' Then 0.90
    End * prod_list_price As "Today's Price"
From a_prd.products
Order By catg_id;

-- demo 04
Select
  catg_id
, prod_id
, prod_list_price
, Case
      When catg_id = 'PET' Then 0.95
      When catg_id = 'SPG' Then 0.95
      When catg_id = 'APL' Then 0.90 Else 'no discount'
    End "Savings %"
From a_prd.products
Order By catg_id;

-- demo 05
Select
  catg_id
, prod_id
, prod_list_price
, Case
      When catg_id = 'PET' Then 0.95
      When catg_id = 'SPG' Then 0.95
      When catg_id = 'APL' Then 0.90 Else 'no discount'
    End * prod_list_price As "Today's Price %"
From a_prd.products
Order By catg_id;

-- demo 06
Select
  catg_id
, prod_id
, prod_list_price
, ROUND(Case
      When catg_id = 'PET' Then 0.95
      When catg_id = 'SPG' Then 0.95
      When catg_id = 'APL' Then 0.90 Else 1
    End * prod_list_price, 2) As "Today's Price"
From a_prd.products
Order By catg_id
;


-- Demo 07	
Select
  catg_id
, prod_id
, prod_list_price
, Case
      When prod_list_price < 50 Then 1
      When catg_id = 'PET' Then 0.95
      When catg_id = 'SPG' Then 0.95
      When catg_id = 'APL' Then 0.90 Else 1
    End * prod_list_price As "Today's Price"
From a_prd.products
Order By catg_id
;



-- Demo 08	
Select
  catg_id
, prod_id
, prod_list_price
, Case
      When catg_id = 'PET' Then Case
          When prod_list_price < 10 Then 'LowCost pet item' Else 'HighCost pet item'
        End
      When catg_id = 'SPG' Then Case
          When prod_list_price < 25 Then 'LowCost sports item'
          When prod_list_price Between 25 And 150 Then 'MidCost sports item' Else 'HighCost sports item'
        End
      When catg_id = 'APL' Then 'appliance item'
    End As "Result"
From a_prd.products
Order By prod_id
;

-- Demo 09
Select
  cust_id
, credit_limit
, Case
      When credit_limit >= 10001 Then 'Superior'
      When credit_limit >= 5001 Then 'Excellent'
      When credit_limit >= 2001 Then 'High'
      When credit_limit >= 1001 Then 'Good' Else 'Standard'
    End As Rating
From a_oe.customers
;


-- Demo 10
Select
  catg_id
, prod_id
, prod_list_price
, Case catg_id
      When 'PET' Then 0.95
      When 'SPG' Then 0.95
      When 'APL' Then 0.90 Else 1
    End * prod_list_price As "Today's Price"
From a_prd.products
;


-- Demo 11
Select
  ord_id
, DATE_FORMAT(ord_date, '%Y/%m/%d') As OrderDate
, Case QUARTER(ord_date)
      When 1 Then 'winter'
      When 2 Then 'spring'
      When 3 Then 'summer'
      When 4 Then 'fall'
    End As "Season"
From a_oe.order_headers
;


-- Demo 12
Select
  catg_id
, prod_id
, prod_list_price
From a_prd.products
Order By Case catg_id When 'PET' Then '1' When 'SPG' Then '2' When 'APL' Then '3' When 'HW' Then '4' Else '9999' End, catg_id, prod_id;