Use a_testbed;

-- Demo 01	
Select
  CONCAT('C', 'AT', ' Fluff', 'y');

Select
  CONCAT('C', 'AT', null, 'y');
  
-- Demo 02	
Select
  CONCAT_WS(' ', 'Fluffy', 'the', 'cat');

Select
  CONCAT_WS(' ', 'Fluffy',null, 'cat');
-- Demo 03
select Concat_ws(' ', prod_desc, 'costs', prod_list_price, 
       'and has a warranty of',prod_warranty_period, 'months') as "Item Desc"
from a_prd.products
limit 4 ;


-- Demo 04	
Select
  an_id
, an_name
, an_type
From zoo_animals
Where an_type = 'dog';



-- Demo 05:	
Select
  an_id
, an_name
, an_type
From zoo_animals
Where binary an_type = 'dog';


-- Demo 06
Select
  UPPER('MY sTrInG')
, UPPER('50 Phelan Ave SF 94112')
, LOWER('MY sTrInG');

-- Demo 07
Select
  RTRIM('     San Francisco  CA   ') As Rtrim
, LTRIM('     San Francisco  CA   ') As Ltrim
, RTRIM(LTRIM('     San Francisco  CA   ')) As "R&LTrim";


-- Demo 08
Select
  RPAD('San Francisco', 15, '-') As RPAD
, LPAD('San Francisco', 15, '-') As LPAD
, RPAD('San Francisco', 5, '-') As "RPad_short";


-- Demo 09
Select
  SUBSTRING('ABCDEFGHIJK', 1, 5)
, SUBSTRING('ABCDEFGHIJK', 5, 3);

Select
  SUBSTRING('ABCDEFGHIJK', 50, 5)
, SUBSTRING('ABCDEFGHIJK', 5, 60);

Select
  SUBSTRING('ABCDEFGHIJK', - 5, 2)
, SUBSTRING('ABCDEFGHIJK', - 50, 20);

-- demo 10

Select
  LEFT('ABCDEFGHIJK', 5)
, RIGHT('ABCDEFGHIJK', 5)
, RIGHT('ABCDEFGHIJK', 55);
-- Demo 11
Select
  SUBSTRING_INDEX('Cat,Ant,Elephant, Blue Frog, Zebra', ',', 1);

-- Demo 12
Select
  SUBSTRING_INDEX('Cat,Ant,Elephant, Blue Frog, Zebra', ',', 3);

-- Demo 13
Select
  SUBSTRING_INDEX('Cat,Ant,Elephant, Blue Frog, Zebra', ',', - 1);


-- Demo 14
Select
  SUBSTRING_INDEX('Cat,Ant,Elephant, Blue Frog, Zebra', 'a', 2);

-- Demo 15
Select
  INSTR('ABCDEABCDE', 'CD')
, INSTR('ABCDEABCDE', 'zebra');

-- Demo 16
Select
  LOCATE('CD', 'ABCDEABCDE')
, LOCATE('CD', 'ABCDEABCDE', 5);


-- Demo 17
Select
  REPLACE('ABCDABCDABCD', 'B', 'cat')
, REPLACE('ABCDABCDABCD', 'BCD', '-');


-- Demo 18
Select
  REPLACE('ABCDABCD', 'CD', '')
, REPLACE('ABCDABCD', 'C', Null);

-- Demo 19
Select
  INSERT('abcdefgh', 1, 4, 'X')
, INSERT('abcdefgh', 5, 2, 'xzyxzy');

-- Demo 20
Select
  LENGTH('   abc   ')
, LENGTH('')
, LENGTH(Null);


-- Demo 21
Select
  REPEAT('*-* ', 3);


-- Demo 22
Select
  REVERSE('abcdefgh');

-- Demo 23
Select
  CONCAT('A', SPACE(5), 'Z');

-- Demo 24
Select
  ASCII('Cat')
, ASCII('Dog')
, ASCII('dog')
, ASCII('')
, ASCII(Null);
-- Demo 25
Select
  CHAR(68) | CHAR(69)
, CHAR(70)
, CHAR(50)
, CHAR(123)
, CHAR(124);

-- Demo 26
Select
  FIELD('cat', 'ant', 'bear', 'catfish', 'dog', 'cat', 'elk');

Select
  FIELD('moose', 'ant', 'bear', 'catfish', 'dog', 'cat', 'elk');

Select
  FIELD(Null, 'ant');

Select
  FIELD('moose', Null);

Select
  FIELD('moose', Null, 'cat');

Select
  FIELD('moose', Null, 'cat', 'moose');

Select
  FIELD(12, 1002, 120, 2011, 12, 2012, 12);

Select
  FIELD(0, 1002, 120, 2011, 12, 2012, 12);

Select
  FIELD(0, 1002, 120, 'ant', 12, 2012, 12);

-- Demo 27
Select
  ELT(2, 'ant', 'cat', 'dog', 'bird', 'hedgehog');

Select
  ELT(8, 'ant', 'cat', 'dog', 'bird', 'hedgehog');

Select
  ELT(0, 'ant', 'cat', 'dog', 'bird', 'hedgehog');


Select
  ELT(3.5, 'ant', 'cat', 'dog', 'bird', 'hedgehog');


-- Demo 28
Select
  FIND_IN_SET('cat', 'ant,bear,catfish,dog,cat,elk');

Select
  FIND_IN_SET('moose', 'ant,bear,catfish,dog,cat,elk');

-- Demo 29
Set @list = 'cat,dog,bird';
Select
  an_type
, FIND_IN_SET(an_type, @list) As Found
From vt_animals;


Select
  an_name
, an_type
From vt_animals
Where FIND_IN_SET(an_type, @list) > 0;

-- Demo 30
Select
  an_name
, an_type
From vt_animals
Where an_type In ('cat', 'dog', 'bird');