Use a_testbed;

-- Demo 01	
Select
  'DOG' = 'dog';

Select
  binary 'DOG' = 'dog';

-- Demo 02	
Select
  CAST(123.567 As char);

Select
  CAST(123.567 As char(2));

-- Demo 03
Select
  CAST('abcsdefg' As char(2));


-- Demo 04	
Select
  CONVERT('123.567', char);


-- Demo 05:	
Select
  FORMAT(1234.5678, 3);



-- Demo 06
Select
  FORMAT(1234.5678, 0);

-- Demo 07
Select
  FORMAT(1234.5678, 8);

-- Demo 08
Select
  LPAD(FORMAT(1234.5678, 8), 20, ' ') As result;

Select
  LPAD(FORMAT(1.5678, 8), 20, ' ') As result;
Select
  LPAD(FORMAT(0.5678, 8), 20, ' ') As result;
Select
  LPAD(FORMAT(- 4.5678, 8), 20, ' ') As result;

-- Demo 09
Select
  LPAD(FORMAT(1234.5678, 8), 2, ' ') As R;