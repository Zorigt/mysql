Use a_testbed;


Create Table z_reg (
  id integer Auto_increment Primary Key
, name varchar(25)
);

Insert Into z_reg (name)
  Values ('Fluffy'), ('goofy'), ('ursula'), ('greg');
Insert Into z_reg (name)
  Values ('pout'), ('Sam 415'), ('pretty bird');
Insert Into z_reg (name)
  Values ('pat'), ('peat'), ('Patricia'), ('Impromptu');
Insert Into z_reg (name)
  Values ('Pete'), ('pat the cat'), ('C3PO');
Insert Into z_reg (name)
  Values ('Mary Proud'), ('ptt'), ('pita');

Select
  *
From z_reg;

-- Demo 01	
Select
  'goofy' Regexp 'goofy' As d_1a
, 'goofy' Regexp 'max' As d_1b;

-- Demo 02	
Select
  'goofy' Regexp 'goofy' As d_2a
, 'goofy' Regexp 'Goofy' As d_2b
, binary 'goofy' Regexp 'Goofy' As d_2c
;

-- Demo 03
Select
  'goofy' Regexp 'g' As d_3a
, 'goofy' Regexp 'oo' As d_3b
, 'goofy' Regexp 'oy' As d_3c
;

-- Demo 04	
Select
  *
From z_reg
Where name Regexp '^g';


-- Demo 05:	
Select
  *
From z_reg
Where name Regexp 'g$';



-- Demo 06
Select
  *
From z_reg
Where name Regexp '^p.t$';

-- Demo 07
Select
  *
From z_reg
Where name Regexp '^p..t$';

-- Demo 08
Select
  *
From z_reg
Where name Not Regexp '^p..t$';

-- Demo 09
Select
  *
From z_reg
Where name Regexp '^p.{3}t';

-- demo 10
Select
  *
From z_reg
Where name Regexp '^p.{4,7}a';

-- Demo 11
Select
  *
From z_reg
Where name Regexp '^p.*t';


-- Demo 12
Select
  *
From z_reg
Where name Regexp 'pr?o';

-- Demo 13
Select
  *
From z_reg
Where name Regexp '[aeiouy]$';

-- Demo 14
Select
  *
From z_reg
Where name Regexp 'r[aeiouy][a-m]';

-- Demo 15
Select
  *
From z_reg
Where name Regexp '[[:blank:]]';

-- Demo 16
Select
  *
From z_reg
Where binary name Regexp '[[:upper:]][[:lower:]]';

-- Demo 17
Select
  *
From z_reg
Where name Regexp '[[:digit:]]';