Use a_testbed;

-- Demo 01	
Select
  ABS(12)
, ABS(- 12)
, ABS(0)
, ABS(45.34);

-- Demo 02	
Select
  SIGN(0)
, SIGN(12)
, SIGN(- 12)
, SIGN(8.9);

-- Demo 03
Select
  POWER(3, 2)
, POWER(10, 3)
, POWER(4.5, 3.2)
, POWER(10, - 3);

Select
  POWER(10, - 3)
, POWER(10.0000, - 3)
, POWER(4.5000, 3.2);
-- Demo 04	
Select
  SQRT(64)
, SQRT(68.56)
, SQRT(- 45);

-- Demo 05:	
Select
  ROUND(45.678, 0)
, ROUND(45.2, 0)
, ROUND(46.5, 0)
, ROUND(45.678, 2);

Select
  ROUND(- 46.5, 0)
, ROUND(345.67, - 2)
, ROUND(45, - 1)
, ROUND(45, - 2);

-- Demo 06
Select
  TRUNCATE(45.678, 0)
, TRUNCATE(45.678, 2)
, TRUNCATE(453446.5, - 2);

-- Demo 07
Select
  CEILING(10)
, CEILING(10.2)
, CEILING(10.8)
, CEILING(- 10.5);

-- Demo 08
Select
  FLOOR(10)
, FLOOR(10.2)
, FLOOR(10.8)
, FLOOR(- 10.5);

-- Demo 09
Select
  MOD(25, 7)
, MOD(12.45, 2.3);


-- demo 10
Create Table a_testbed.z_numerics (
  id int
, val_1 float
);

Insert Into a_testbed.z_numerics
  Values (1, 25.0034)
  , (2, 25.0079)
  , (3, 25.0279)
  , (4, 25.4239)
  , (5, - 25.0279)
  , (6, - 25.4239)
;

-- demo 11
Select
  id
, val_1
, ROUND(val_1, 2) As "round"
, TRUNCATE(val_1, 2) As "truncate"
, CEILING(val_1 * 100.00) / 100.00 As "ceil"
, FLOOR(val_1 * 100.00) / 100.00 As "floor"
From a_testbed.z_numerics
;

-- demo 12
Select
  quoted_price As price
, ROUND(quoted_price, - 1) As Price_10
, ROUND(quoted_price, - 2) As Price_100
From a_oe.order_details
Limit 10
;

-- demo 13
Select
  RAND() As col_1
, RAND() As col_2
, RAND() As col_3;

Select
  RAND(5) As col_1
, RAND(5) As col_2
, RAND(5) As col_3;

Select
  RAND(5) As col_1
, RAND() As col_2
, RAND() As col_3;

Select
  FLOOR(RAND() * 20 + 1) As col_1;


-- Demo 14
Select
  FLOOR(RAND() * 20 + 1) As col_1;

Select
  (FLOOR(RAND() * (10 - 3)) + 3) / 10;