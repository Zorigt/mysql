Use a_testbed;

Create Table z_numbers (
  A integer
, B integer
, C integer
, D integer
, E integer
, F integer
);

Insert Into z_numbers
  Values (1, 10, 10, 50, 90, 45);
Insert Into z_numbers
  Values (2, 15, 5, Null, 10, 0);
Insert Into z_numbers
  Values (3, Null, Null, 50, 50, - 1);
Insert Into z_numbers
  Values (4, Null, Null, Null, Null, Null);
Insert Into z_numbers
  Values (5, 0, 0, 0, 0, 0);
Insert Into z_numbers
  Values (6, 10, 10, 10, 10, 10);
Insert Into z_numbers
  Values (7, - 10, 10, 0, - 210, 85);
Insert Into z_numbers
  Values (8, - 10, Null, 0, - 210, 85);
Insert Into z_numbers
  Values (9, 200, 3, 0, 200, 85);
Insert Into z_numbers
  Values (10, 200, 200, 0, 5, 46);


-- Demo 01	
Select
  A
, COALESCE(B, C, D, E)
, COALESCE(B, 9999)
From z_numbers
;
Select
  A
, COALESCE(B, 0)
, COALESCE(D, 0)
From z_numbers
;
-- Demo 02	
Select
  A
, B
, IFNULL(B, 87) As B_Null
, D
, IFNULL(D, 0) As D_Null
From z_numbers
;

-- Demo 03
Select
  A
, IFNULL(B, IFNULL(C, IFNULL(D, E))) As Result
From z_numbers
;

-- Demo 04	
Select
  A
, B
, C
, NULLIF(B, C)
From z_numbers
;

-- Demo 05:	
Select
  A
, F
, NULLIF(F, - 1)
From z_numbers
;

-- Demo 06
Select
  A
, B
, NULLIF(B, 200)
, D
, NULLIF(85, F)
From z_numbers
;

-- Demo 07
Select
  A
, B
, NULLIF(0, B - B) As Flipped
From z_numbers
;

-- Demo 08
Select
  D
From z_numbers;


Select
  D
From z_numbers
Where D Is Not Null;
Select
  A
, B
, ISNULL(B)
From z_numbers
;
Select
  AVG(D)
, AVG(NULLIF(D, 0))
From z_numbers;

-- Demo 09
Select
  A
, B
From z_numbers
Where ISNULL(B)
;
-- demo 10
Select
  A
, B
From z_numbers
Where B Is Null;


-- demo 11
Select
  A
, B
From z_numbers
Where 56;

Select
  A
, B
From z_numbers
Where 0;

-- Demo 12
Select
  an_id
, an_name
, an_type
From a_vets.vt_animals
Order By an_name;

-- Demo 12
Select
  an_id
, an_name
From a_vets.vt_animals
Where LENGTH(an_name)
Order By an_name;

-- Demo 13
Select
  an_id
, an_name
From a_vets.vt_animals
Where Not LENGTH(an_name)
Order By an_name;

-- Demo 14
Select
  an_id
, an_name
From a_vets.vt_animals
Where an_name Is Null
Order By an_name;