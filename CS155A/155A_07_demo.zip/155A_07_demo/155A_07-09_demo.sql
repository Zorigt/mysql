Use a_testbed;

-- demo 01	
Select
  YEAR('000731')
, YEAR(000731)
, YEAR(731);

Select
  MONTH('000731')
, MONTH(000731)
, MONTH(731);

-- demo 02
Select
  CURDATE()
, CURRENT_DATE()
, CURRENT_DATE; -- these are synonyms

Select
  NOW();

-- demo 03 
Select
  CAST('2015-05-31' As date)
, CAST('2015-05-31' As datetime);

-- demo 04
Select
  CURRENT_DATE
, LEFT(CURRENT_DATE, 4) As Str1
, SUBSTRING(CURRENT_DATE, 6, 2) As Str2
, SUBSTRING(CURRENT_DATE, 9, 2) As Str3
;

-- demo 05
Select
  CURRENT_DATE
, YEAR(CURRENT_DATE) As Str1
, MONTH(CURRENT_DATE) As Str2
, DAYOFMONTH(CURRENT_DATE) As Str3;

-- demo 06
Set @d := '2011-02-20';
Select
  DATE_FORMAT(@d, '%Y/%m/%d')
, DATE_FORMAT(@d, '%M %D');

-- demo 07
Select
  STR_TO_DATE('July 4, 2012', '%M %e, %Y');
Select
  STR_TO_DATE('July 4, 2012', '%M %e %Y');

-- demo 08
Set @d = '2009-08-15';

select
YEAR(@d), MONTH(@d), WEEK(@d), DAYOFMONTH(@d),
DAYOFWEEK(@d), DAYOFYEAR(@d), 
MONTHNAME(@d), DAYNAME(@d)
;

-- demo 09
Select
  hire_date
, EXTRACT(year From hire_date) As "YearHired"
, EXTRACT(Month From hire_date) As "MonthHired"
, EXTRACT(Day From hire_date) As "DayHired"
From a_emp.employees
Limit 4;

-- demo 10	
Select
  emp_id
, hire_date
From a_emp.employees
Where EXTRACT(Month From hire_date) = 8
;

-- demo 11:	
Select
  emp_id
, hire_date
From a_emp.employees
Where EXTRACT(year From hire_date) = EXTRACT(year From CURRENT_DATE())
;

-- demo 12
Set @d = '2011-08-15  20:15:33';
Select
  @d
, YEAR(@d) As year
, QUARTER(@d) As quarter
, MONTH(@d) As month
, DAY(@d) As day
, HOUR(@d) As hour
, MINUTE(@d) As minute
;

-- demo 13
Select
  @d
, DAYNAME(@d)
, MONTHNAME(@d)
;
Select
  @d
, DAYOFWEEK(@d)
, WEEKDAY(@d);

Show Variables Like 'default_week_format';

-- demo 14
Set @dtm = '2009-01-03';
Select
  WEEK(@dtm) As m_default
, WEEK(@dtm, 0) As m_0
, WEEK(@dtm, 1) As m_1
, WEEK(@dtm, 2) As m_2
, WEEK(@dtm, 3) As m_3
, WEEK(@dtm, 4) As m_4
, WEEK(@dtm, 5) As m_5
, WEEK(@dtm, 6) As m_6
, WEEK(@dtm, 7) As m_7;

-- demo 15
Set @dtm = '2009-01-10';
Select
  WEEK(@dtm) As m_default
, WEEK(@dtm, 0) As m_0
, WEEK(@dtm, 1) As m_1
, WEEK(@dtm, 2) As m_2
, WEEK(@dtm, 3) As m_3
, WEEK(@dtm, 4) As m_4
, WEEK(@dtm, 5) As m_5
, WEEK(@dtm, 6) As m_6
, WEEK(@dtm, 7) As m_7;

-- demo 16
Set @d = '2011-02-20';
Select
  @d
, DATE_ADD(@d, Interval 40 Day) As '40days'
, DATE_ADD(@d, Interval 40 year) As '40years'
, DATE_ADD(@d, Interval 51 Month) As '51months';

-- demo 17
Select
  DATE_ADD('2009-01-31', Interval 1 Month) As Jan31
, DATE_ADD('2009-01-28', Interval 1 Month) As Jan28;

-- demo 18
Set @d := '2011-02-20 19:55:09';
Select
  @d
, DATE_ADD(@d, Interval '4 3' Year_month) As '4 years 3 months'
, DATE_ADD(@d, Interval '2-23' Day_hour) As '2 days 23 hours'
;

-- demo 19
Set @d := '2011-02-20 ';
Select
  @d
, DATE_ADD(@d, Interval '-4 3' Year_month) As 'minus 4 years 3 months'
, DATE_ADD(@d, Interval '-2' Day) As 'minus 2 days'
;

-- demo 20
Set @d := '2011-02-20';
Select
  @d
, DATE_SUB(@d, Interval 40 Day) As '40days'
, DATE_SUB(@d, Interval 40 year) As '40years'
, DATE_SUB(@d, Interval 51 Month) As '51months'
;

-- demo 21
Set @d = '2009-07-06';
Select
  @d
, SUBDATE(@d, Interval 40 Day) As '40days'
, SUBDATE(@d, 40) As '40days'
;

-- demo 22
Select
  @d
, DATEDIFF(@d, '20090720') As col_2
, DATEDIFF(@d, '20090620') As col_3
, DATEDIFF(@d, '20070706') As col_4
;

-- demo 23
Select
  DATEDIFF('2009-07-06 23:59:59', '2009-07-07 00:00:01');

-- demo 24
select   ord_id
,        ord_date 
from     a_oe.order_headers
where    dateDiff( '2012-06-30', ord_date) between 25 and 50;

-- demo 25
Select
  CURRENT_DATE()
, TO_DAYS(CURRENT_DATE()) As NowCount
, TO_DAYS('2009-07-20') As "20090720"
, TO_DAYS('1066-10-14') As "btlHst"
, TO_DAYS('0079-08-24') As "MtVsv"
;

-- demo 26
Set @d1 := '2011-08-17';
Set @d2 := '2011-12-17';

Select
  TO_DAYS(@d2) - TO_DAYS(@d1)
;

-- demo 27
Select
  FROM_DAYS(5)
, FROM_DAYS(500)
, FROM_DAYS(689798)
, FROM_DAYS(733736);

-- demo 28
Set @d1 = '2011-03-25';
Set @d2 = '2011-03-31';
Select
  LAST_DAY(@d1)
, LAST_DAY(@d2);

select last_day (From_days(689798));

-- demo 29
Select
  NOW()
, NOW() + 40 As Plus40
, MONTH(NOW() + 40) As Month40
;

-- demo 30
Select
  CURDATE()
, CURDATE() + 40 As Plus40
, MONTH(CURDATE() + 40) As Month40;

-- demo 31
Select
  NOW()
, NOW() + 4 As Plus4
, MONTH(NOW() + 4) As Month4;

-- demo 32
Select
  MONTH('2525-00-00');

-- demo 33
Set @d := '2011-02-20';
Select
  @d
, DATE_ADD(@d, Interval + 1 Month);


-- demo 34
Select
  @d
, CAST(DATE_ADD(@d, Interval + 1 Month) As char(8)) As WorkingDate;

-- demo 35
Select
  @d
, CONCAT(CAST(DATE_ADD(@d, Interval + 1 Month) As char(8)), '15') As WorkingDate;


-- demo 36
Select
  CAST(ord_date As date) As OrderDate
, CAST(CONCAT(CAST(DATE_ADD(ord_date, Interval + 1 Month) As char(8)), '15') As date) As DueDate
From a_oe.order_headers;