use a_testbed;

Create Table z_dates (
  id int Primary Key
, dtm date
);

Insert Into z_dates
  Values (1, '2010-02-28');
-- this one fails
Insert Into z_dates
  Values (2, '2010-02-29');

Insert into z_dates values (3, '2010-02-00');
Insert Into z_dates
  Values (4, '2010-00-00');
Insert Into z_dates
  Values (5, '0000-00-00');
Insert Into z_dates
  Values (6, '2010-04-29');
Insert Into z_dates
  Values (7, '2010-00-29');
Insert Into z_dates
  Values (8, '2010-04-00');
Insert Into z_dates
  Values (9, '2010-04-15');
Insert Into z_dates
  Values (10, '0000-04-29');

Select
  *
From z_dates;


-- demo 01
Select
  *
From z_dates
Order By dtm;

-- demo 02
Select
  *
From z_dates
Where MONTH(dtm) = 2;

-- demo 03
Select
  *
From z_dates
Where DAY(dtm) = 29;

-- demo 04
Select
  id
, dtm
, MONTH(dtm)
From z_dates;

-- demo 05
Select
  id
, dtm
, DATE_ADD(dtm, Interval 5 Day)
From z_dates;


-- demo 06
Select
  id
, dtm
, DATE_ADD(dtm, Interval 5 Month)
From z_dates;

-- demo 07
Select
  id
, dtm
, DATE_ADD(dtm, Interval 15 Month)
From z_dates;

-- demo 08
Select
  id
, dtm
, DATE_FORMAT(dtm, '%M %e, %Y')
From z_dates;