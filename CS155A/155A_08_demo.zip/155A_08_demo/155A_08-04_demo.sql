Use a_testbed;

/*   Demo  01  */	
Create Table a_testbed.z_group (
  an_id integer Primary Key
, an_name varchar(15) Not Null
, an_type varchar(15) Not Null
, an_price integer Not Null
);

/*   Demo  02  */	
Select
  an_name
, COUNT(*)
From a_testbed.z_group
Group By an_name;

/*   Demo  03  */	
Select
  an_name
, an_type
, an_price
, COUNT(*)
From a_testbed.z_group
Group By an_name;

/*   Demo  04  */	
Select
  an_name
, an_type
, an_price
, COUNT(*)
From a_testbed.z_group
Group By an_name, an_type, an_price;

/*   Demo  05  */	
Select
  an_name
, MAX(an_price)
, COUNT(*)
From a_testbed.z_group
Group By an_name;

/*   Demo  06  */	
Select
  cust_id
, ord_id
, shipping_mode
, COUNT(*) As "NumberLineItems"
From a_oe.order_headers
Inner Join a_oe.order_details Using (ord_id)
Group By ord_id, cust_id, shipping_mode
Order By cust_id, ord_id;

/*   Demo  07  */	
Select
  cust_id
, ord_id
, shipping_mode
, COUNT(*) As "NumberLineItems"
From a_oe.order_headers
Inner Join a_oe.order_details Using (ord_id)
Group By ord_id
Order By cust_id, ord_id;

/*   Demo  08  */	
Select
  cust_id
, cust_name_last
, ord_id
, ord_date
, SUM(quantity_ordered * quoted_price) As amntdue
From a_oe.customers
Inner Join a_oe.order_headers Using (cust_id)
Inner Join a_oe.order_details Using (ord_id)
Group By ord_id, cust_id, cust_name_last, ord_date
Order By cust_id, ord_id;

/*   Demo  09  */	
Select
  cust_id
, cust_name_last
, ord_id
, ord_date
, SUM(quantity_ordered * quoted_price) As amntdue
From a_oe.customers
Inner Join a_oe.order_headers Using (cust_id)
Inner Join a_oe.order_details Using (ord_id)
Group By ord_id
Order By cust_id, ord_id;

/*   Demo  10  */	
Select
  cust_id
, cust_name_last
, ord_id
, CAST(ord_date As date) As OrderDate
, SUM(quantity_ordered * quoted_price) As amntdue
From a_oe.customers
Inner Join a_oe.order_headers Using (cust_id)
Inner Join a_oe.order_details Using (ord_id)
Group By ord_date
Order By cust_id, ord_id;

/*   Demo  11  */	
Select
  cust_id
, cust_name_last
, ord_id
, CAST(ord_date As date) As OrderDate
, SUM(quantity_ordered * quoted_price) As amntdue
From a_oe.customers
Inner Join a_oe.order_headers Using (cust_id)
Inner Join a_oe.order_details Using (ord_id)
Where ord_date = '2012-06-04'
Group By ord_id
Order By cust_id, ord_id;

/*   Demo  12  */	
Select
  cust_id
, cust_name_last
, ord_id
, CAST(ord_date As date) As OrderDate
, SUM(quantity_ordered * quoted_price) As amntdue
From a_oe.customers
Inner Join a_oe.order_headers Using (cust_id)
Inner Join a_oe.order_details Using (ord_id)
Where ord_date = '2012-06-04'
Group By ord_date
Order By cust_id, ord_id;

/*   Demo  13  */	
Select
  CAST(ord_date As date) As OrderDate
, COUNT(*) As NumberOfOrders
, SUM(quantity_ordered * quoted_price) As amntdue
From a_oe.order_headers
Join a_oe.order_details Using (ord_id)
Group By OrderDate
Order By OrderDate
;
/*   Demo  14  */	
Select
  an_type
, COUNT(*)
, GROUP_CONCAT(an_name)
From a_testbed.z_group
Group By an_type;

/*   Demo  15  */	
Select
  an_type
, COUNT(*)
, GROUP_CONCAT(Distinct an_name)
From a_testbed.z_group
Group By an_type;

/*   Demo  16  */	
Select
  an_type
, COUNT(*)
, GROUP_CONCAT(an_price Order By an_price)
From a_testbed.z_group
Group By an_type;

/*   Demo  17  */	
Select
  an_type
, COUNT(*)
, GROUP_CONCAT(CONCAT(an_name, ' at $', an_price))
From a_testbed.z_group
Group By an_type;

/*   Demo  18  */
Select
  LEFT(ord_date, 10) As OrdDate
, GROUP_CONCAT(prod_id Order By prod_id) As ProductsSold
, GROUP_CONCAT(Distinct prod_id Order By prod_id) As DistinctProductsSold
From a_oe.customers
Inner Join a_oe.order_headers Using (cust_id)
Inner Join a_oe.order_details Using (ord_id)
Where YEAR(ord_date) = 2012
Group By ord_date
Order By ord_date
;