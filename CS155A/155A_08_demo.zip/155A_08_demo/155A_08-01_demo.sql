Use a_emp;

/*   Demo  01  */   
Select
  AVG(prod_list_price) As "AvgPrice"
From a_prd.products
;

/*   Demo  02  */   
Select
  AVG(prod_list_price) As "AvgPrice"
From a_prd.products
Where catg_id = 'HW';

/*   Demo  03  */   
Select
  AVG(prod_list_price) As "Avg Price"
, MIN(prod_list_price) As "Min Price"
, MAX(prod_list_price) As "Max Price"
From a_prd.products
Where catg_id = 'HW';

/*   Demo  04  */   
Select
  AVG(prod_list_price) As "AvgListPrice"
, AVG(quoted_price) As "AvgQuotedPrice"
, AVG(quoted_price * quantity_ordered) As "AvgExtendedCost"
, SUM(quoted_price * quantity_ordered) As "TotalExtendedCost"
From a_prd.products
Join a_oe.order_details Using (prod_id)
Where catg_id = 'HW';

/*   Demo  05  */   
Select
  ROUND(AVG(prod_list_price), 0) As "Avg Price"
, MAX(prod_list_price) - MIN(prod_list_price) As "Price Range"
From a_prd.products
;
/*   Demo  06  */  
Select
  MAX(prod_list_price) As "Max Price"
From a_prd.products
;

/*   Demo  07  */   
Select
  MAX(prod_list_price) As "Max Price"
, prod_id
From a_prd.products
;

/*   Demo  08  */   
Select    
  prod_id
, prod_name
, prod_list_price
From  a_prd.products
Where prod_list_price = MAX(prod_list_price);

/*   Demo  09  */  
Select
  prod_id
, prod_name
, prod_list_price
From a_prd.products
Where prod_list_price = (
  Select
    MAX(prod_list_price) As "Largest Price"
  From a_prd.products
);

/*   Demo  10  */   
Select
  prod_id
, prod_name
From a_prd.products
Where prod_list_price = (
  Select
    MAX(prod_list_price) As "Largest Price"
  From a_prd.products
  Where catg_id = 'SPG'
);

/*   Demo  11  */   
Set @catg_id = 'SPG';
Select
  prod_id
, prod_name
From a_prd.products
Where catg_id = @catg_id
And prod_list_price = (
  Select
    MAX(prod_list_price) As "Largest Price"
  From a_prd.products
  Where catg_id = @catg_id
);

/*   Demo  12  */   
Set @catg_id = 'PET';

Select
  prod_id
, prod_name
From a_prd.products
Where catg_id = @catg_id
And prod_list_price = (
  Select
    MAX(prod_list_price) As "Largest Price"
  From a_prd.products
  Where catg_id = @catg_id
);

/*   Demo  13  */  
Select
  MIN(ord_date) As "Earliest"
From a_oe.order_headers;

/*   Demo  14  */  
Select
  MIN(hire_date) As "Earliest"
, MAX(hire_date) As "Recent"
From a_emp.employees;

/*   Demo  15  */  
Select
  MIN(name_last)
, MAX(name_last)
From a_emp.employees;

/*   Demo  16  */   
Select
  COUNT(prod_id) As "Number of Products"
, COUNT(prod_warranty_period) As "Number with warranty"
From a_prd.products
;

/*   Demo  17  */   
Select
  COUNT(prod_id) As "Number of Products"
, COUNT(*) As "Number of rows *"
, COUNT(1) As "Number of rows 1"
From a_prd.products
;

/*   Demo  18  */   
Select
  COUNT(Distinct prod_id)
From a_oe.order_details
;

/*   Demo  19  */   
Select
  COUNT(ord_id)
From a_oe.order_headers
;

/*   Demo  20  */  
Select
  COUNT(ord_id)
, COUNT(Distinct ord_id)
From a_oe.order_details;


/*   Demo  21  */  
Select
  COUNT(Distinct cust_id)
, COUNT(cust_id)
From a_oe.order_headers;



/*   Demo  22  */  
Select
  COUNT(Distinct cust_id, shipping_mode)
From a_oe.order_headers
Where shipping_mode Is Not Null;