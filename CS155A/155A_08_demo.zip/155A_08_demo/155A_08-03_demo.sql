Use a_emp;

/*   Demo  01  */	
Select
  catg_id
, SUM(quantity_ordered) As QuantitySold
From a_oe.order_details
Inner Join a_prd.products Using (prod_id)
Group By catg_id
;

/*   Demo  02  */
Select
  SUM(quantity_ordered) As QuantitySold
From a_oe.order_details
Join a_prd.products Using (prod_id)
Where catg_id = 'APL'
;

/*   Demo  03  */
Select
  SUM(Case
      When catg_id = 'APL' Then quantity_ordered Else Null
    End) APL_QuantitySold
From a_oe.order_details
Join a_prd.products Using (prod_id)
;
/*   Demo  04  */	
Select
  SUM(Case
      When catg_id = 'APL' Then quantity_ordered Else Null
    End) APL_QuantitySold
, SUM(Case
      When catg_id = 'SPG' Then quantity_ordered Else Null
    End) SPG_QuantitySold
, SUM(Case
      When catg_id = 'HW' Then quantity_ordered Else Null
    End) HW_QuantitySold
, SUM(Case
      When catg_id = 'PET' Then quantity_ordered Else Null
    End) PET_QuantitySold
From a_oe.order_details
Inner Join a_prd.products On a_oe.order_details.prod_id = a_prd.products.prod_id
;

/*   Demo  05  */	
Select
  ord_id
, SUM(Case
      When catg_id = 'APL' Then quantity_ordered Else Null
    End) As APL_Quant
, SUM(Case
      When catg_id = 'SPG' Then quantity_ordered Else Null
    End) As SPG_Quant
, SUM(Case
      When catg_id = 'HW' Then quantity_ordered Else Null
    End) As HW_Quant
, SUM(Case
      When catg_id = 'PET' Then quantity_ordered Else Null
    End) As PET_Quant
From a_oe.order_details
Inner Join a_prd.products On a_oe.order_details.prod_id = a_prd.products.prod_id
Group By ord_id
;
/*   Demo  06  */	
Set @Mnth_1   */= 10;
Set @Mnth_2   */= 11;
Set @Mnth_3   */= 12;

Select
  cust_id
, COUNT(Case
      When MONTH(ord_date) = @Mnth_1 Then 1 Else Null
    End) As "Month 1"
, COUNT(Case
      When MONTH(ord_date) = @Mnth_2 Then 1 Else Null
    End) As "Month 2"
, COUNT(Case
      When MONTH(ord_date) = @Mnth_3 Then 1 Else Null
    End) As "Month 3"
From a_oe.order_headers
Where YEAR(ord_date) = YEAR(CURDATE()) - 1
Group By cust_id
Order By cust_id;


/*   Demo  07  */	
Select
  SUM(Case
      When quoted_price Between 0.01 And 25 Then quantity_ordered Else 0
    End) As "Price 0.01-25"
, SUM(Case
      When quoted_price Between 25.01 And 100 Then quantity_ordered Else 0
    End) As "Price 25.01-100"
, SUM(Case
      When quoted_price Between 100.01 And 250 Then quantity_ordered Else 0
    End) As "Price 100.01- 250"
, SUM(Case
      When quoted_price > 250 Then quantity_ordered Else 0
    End) As "Price > 250"
, SUM(quantity_ordered) As "Tot Quant"
From a_oe.order_details
;

/*   Demo  08  */	

Select
    Case
      When quoted_price Between 0.01 And 25 Then 'Price   0.01 -  25'
      When quoted_price Between 25.01 And 100 Then 'Price  25.01 - 100'
      When quoted_price Between 100.01 And 250 Then 'Price 100.01 - 250'
      When quoted_price > 250 Then 'Price over 250'
    End As "Price Range"
  , SUM(quantity_ordered) As "Total Quantity"
From a_oe.order_details
Group By Case When quoted_price Between 0.01 And 25 Then 'Price   0.01 -  25' When quoted_price Between 25.01 And 100 Then 'Price  25.01 - 100' When quoted_price Between 100.01 And 250 Then 'Price 100.01 - 250' When quoted_price > 250 Then 'Price over 250' End
Order By 1
;