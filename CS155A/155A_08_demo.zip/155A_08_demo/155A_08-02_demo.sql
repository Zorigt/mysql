Use a_emp;

/*   Demo  01  */	
Select
  dept_id
From a_emp.employees
;


/*   Demo  02  */	
Select
  dept_id
From a_emp.employees
Group By dept_id
;

/*   Demo  03  */  
Select
  dept_id
, emp_id
From a_emp.employees
Group By dept_id
;

/*   Demo  04  */	
Select
  dept_id
, job_id
From a_emp.employees
Group By dept_id, job_id;

/*   Demo  05  */  
Select
  dept_id
, job_id
From a_emp.employees
Group By job_id, dept_id;

/*   Demo  06  */  
Select
  dept_id
, job_id
From a_emp.employees
Group By job_id, dept_id
Order By dept_id, emp_id;


/*   Demo  07  */	
Select
  dept_id
, COUNT(*)
, AVG(salary)
From a_emp.employees
Group By dept_id
;

/*   Demo  08  */	
Select
  catg_id
, AVG(prod_list_price) As "Avg List Price"
, MAX(prod_list_price) As "Max List Price"
From a_prd.products
Group By catg_id
;

/*   Demo  09  */	
Select
  dept_id
, job_id
, COUNT(*) As NumEmployee
, AVG(salary) As AvgSalary
From a_emp.employees
Group By dept_id, job_id
Order By AVG(salary);


/*   Demo  10  */	
Select
  COUNT(*) As NumEmployee
, AVG(salary) As AvgSalary
From a_emp.employees
Group By dept_id, job_id
Order By AVG(salary);

/*   Demo  11  */	
Select
  catg_id
, MAX(prod_list_price) As MaxPrice
From a_prd.products
Group By catg_id
;

/*   Demo  12  */	
Select
  p.catg_id
, p.prod_id
, p.prod_list_price
, p.prod_desc
From a_prd.products P
Where (p.catg_id, p.prod_list_price)
In (
  Select
    catg_id
  , MAX(prod_list_price) As MaxPrice
  From a_prd.products
  Group By catg_id
);

/*   Demo  13  */	
Select
  dept_id
, COUNT(*)
, AVG(salary)
From a_emp.employees
Group By dept_id
;

/*   Demo  14  */	
Select
  dept_id
, COUNT(*)
, AVG(salary)
From a_emp.employees
Group By dept_id
Having AVG(salary) > 30000
;

/*   Demo  15  */	
Select
  dept_id
, COUNT(*)
, AVG(salary)
From a_emp.employees
Where dept_id Between 30 And 40
Group By dept_id
Having AVG(salary) > 30000
;

/*   Demo  16  */	
Select
  dept_id
, COUNT(*)
, AVG(salary)
From a_emp.employees
Where salary > 30000
Group By dept_id
;


/*   Demo  17  */	
Select
  dept_id
, COUNT(*)
, AVG(salary)
From a_emp.employees
Group By dept_id
Having COUNT(*) > 3
;

/*   Demo  18  */	
Select
  name_last As DuplicateName
, COUNT(*)
From a_emp.employees
Group By name_last
Having COUNT(*) > 1;

/*   Demo  19  */  
Select
  ord_id
, COUNT(*) As "NumberLineItems"
From a_oe.order_headers
Inner Join a_oe.order_details Using (ord_id)
Group By ord_id
Order By ord_id
;


/*   Demo  20  */  
Select
  cust_id
, ord_id
, shipping_mode
, COUNT(*) As "NumberLineItems"
From a_oe.order_headers
Inner Join a_oe.order_details Using (ord_id)
Group By ord_id
Order By cust_id, ord_id;


/*   Demo  20 alt  */  
Select
  cust_id
, ord_id
, shipping_mode
, COUNT(*) As "NumberLineItems"
From a_oe.order_headers
Inner Join a_oe.order_details Using (ord_id)
Group By ord_id, cust_id, shipping_mode
Order By cust_id, ord_id;


/*   Demo  21  */  
Select
  cust_id
, cust_name_last
, ord_id
, CAST(ord_date As date) As OrderDate
, SUM(quantity_ordered * quoted_price) As amntdue
From a_oe.customers
Inner Join a_oe.order_headers Using (cust_id)
Inner Join a_oe.order_details Using (ord_id)
Group By ord_id, cust_id, cust_name_last, ord_date
Order By cust_id, ord_id;


/*   Demo  22	  */  
Select
  COUNT(*) As "NumProducts"
, COUNT(prod_warranty_period) As "NumWithWarranty"
From a_prd.products
;

/*   Demo  23  */  
Select
  prod_warranty_period
, COUNT(*) As "NumProducts"
From a_prd.products
Group By prod_warranty_period
Order By prod_warranty_period
;

/*   Demo  24  */  
Select
  COALESCE((prod_warranty_period), 'no warranty') As "Warranty"
, COUNT(*) As "NumProducts"
From a_prd.products
Group By prod_warranty_period
Order By prod_warranty_period
;



/*   Demo  25  */  
Use a_testbed;

Create Table z_aggs (
  id integer
, fee decimal(5, 2)
);

Insert Into z_aggs
  Values (1, 45);
Insert Into z_aggs
  Values (2, 0);
Insert Into z_aggs
  Values (3, Null);
Insert Into z_aggs
  Values (4, Null);


Select
  COUNT(*)
, COUNT(id)
, COUNT(fee)
, SUM(fee)
, AVG(fee)
, MAX(fee)
From z_aggs;


Select
  COUNT(*)
, COUNT(fee)
, MAX(fee)
From z_aggs
Group By fee;