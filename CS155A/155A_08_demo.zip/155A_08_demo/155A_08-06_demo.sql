Use a_testbed;

/*   Demo  01  */	
show create table a_testbed.zoo_animals\G
/*   Demo  02  */	
show databases;   

/*   Demo  03  */	
show tables from information_schema;

/*   Demo  04  */	
desc information_schema.tables

Select table_name, create_time
From information_schema.tables
Where table_schema= 'a_emp';


/*   Demo  05  */	
desc information_schema.table_constraints;

/*   Demo  06  */	
Select TC.table_name , count(*)
From information_schema.table_constraints TC
Where TC.table_schema= 'a_emp'
and TC.constraint_type = 'FOREIGN KEY'
Group by TC.table_name;


/*   Demo  07  */	
desc information_schema.columns; 

/*   Demo  08  */	
Select table_name, column_name, data_type
From information_schema.columns
Where table_schema= 'a_emp'
and data_type not in ('CHAR', 'VARCHAR');


/*   Demo  09  */	
Select table_schema, table_name, table_type, table_rows
From information_schema.tables
Where table_schema= 'a_emp';


/*   Demo  10  */	
Show tables;

/*   Demo  11  */	
Select TC.table_name, TC.constraint_name, TC.constraint_type
From information_schema.table_constraints TC
Where TC.table_schema= 'a_emp';


/*   Demo  12  */	
Select TC.table_name, TC.constraint_name, TC.constraint_type
From information_schema.table_constraints TC
Where TC.table_schema= 'a_emp'
and constraint_type <> 'PRIMARY KEY';


/*   Demo  13  */	
Create table a_emp.vt_temp (col_id int);

Select TC.table_name, TC.constraint_name, TC.constraint_type
From information_schema.table_constraints TC
Where TC.table_schema= 'a_emp';

/*   Demo  14  */	
Select Concat(T.table_schema,'- - - ', T.table_name)
From information_schema.tables T
Where T.table_schema= 'a_emp'
and
  Concat(T.table_schema,'- - - ', T.table_name) NOT IN (
   Select Concat(TC.table_schema,'- - - ', TC.table_name)
   From information_schema.table_constraints TC
   Where TC.table_schema= 'a_emp'
   and TC.constraint_type = 'PRIMARY KEY'
   );


/*   Demo  15  */	
Select Concat(T.table_schema,'- - - ', T.table_name)
From information_schema.tables T
Where 
   T.table_schema= 'a_emp'   
and
  Concat(T.table_schema,'- - - ', T.table_name) NOT IN (
     Select Concat(TC.table_schema,'- - - ', TC.table_name)
     From information_schema.table_constraints TC
     Where TC.table_schema= 'a_emp'
     and  TC.constraint_type = 'PRIMARY KEY'
);


/*   Demo  16  */	
Select Concat(T.table_schema,'- - - ', T.table_name)
From information_schema.tables T
Where 
   T.table_schema= 'a_emp'
and
   T.TABLE_TYPE = 'BASE TABLE'     
and
  Concat(T.table_schema,'- - - ', T.table_name) NOT IN (
     Select Concat(TC.table_schema,'- - - ', TC.table_name)
     From information_schema.table_constraints TC
     Where TC.table_schema= 'a_emp'
     and  TC.constraint_type = 'PRIMARY KEY'
);


/*   Demo  17  */	
drop table a_emp.vt_temp;

/*   Demo  18  */
Show tables;

Show full tables from a_testbed Like 'ddl%' ;

v