
Create Table a_testbed.TodaysSpecials (
  an_type varchar(15)
);
truncate table a_testbed.TodaysSpecials;
Insert Into a_testbed.TodaysSpecials
  Values ('fish');
Insert Into a_testbed.TodaysSpecials
  Values ('cat');

/*  demo 01  */	
Select
  *
From a_testbed.zoo_ex
Where an_type = Any (
  Select
    an_type
  From a_testbed.todaysSpecials
);

/*  demo 02  */	
Select
  *
From a_testbed.zoo_ex
Where an_type = All (
  Select
    an_type
  From a_testbed.todaysSpecials
);

/*  demo 03  */	
Select
  *
From a_testbed.zoo_ex
Where an_price > Any (
  Select
    an_price
  From zoo_ex
)
Order By an_price;

/*  demo 04  */	
Select
  *
From a_testbed.zoo_ex
Where an_price >= Any (
  Select
    an_price
  From zoo_ex
)
Order By an_price;

/*  demo 05  */	
Select
  *
From a_testbed.zoo_ex
Where an_price > All (
  Select
    an_price
  From a_testbed.zoo_ex
)
Order By an_price;

/*  demo 06  */	
Select
  *
From a_testbed.zoo_ex
Where an_price >= All (
  Select
    an_price
  From a_testbed.zoo_ex
)
Order By an_price;

/*  demo 07  */	
Select
  *
From a_testbed.zoo_ex
Where an_price >= All (
  Select
    an_price
  From a_testbed.zoo_ex
  Where an_price Is Not Null
)
Order By an_price;

/*  demo 08  */		
Select
  *
From a_testbed.zoo_ex
Where an_price = Any (
  Select
    an_price
  From a_testbed.zoo_ex
  Where an_price Is Not Null
  And an_type = 'bird'
);

/*  demo 09  */	
select * 
from a_testbed.zoo_ex
where an_price = ANY (
    select an_price 
    from   a_testbed.zoo_ex 
    where  an_type ='lizard'
    and    an_price is not null);

/*  demo 10  */	
Select
  *
From a_testbed.zoo_ex
Where an_price = All (
  Select
    an_price
  From a_testbed.zoo_ex
  Where an_price Is Not Null
  And an_type = 'bird'
);

/*  demo 11  */	
Select
  *
From a_testbed.zoo_ex
Where an_price = All (
  Select
    an_price
  From a_testbed.zoo_ex
  Where an_price Is Not Null
  And an_type = 'lizard'
);

/*  demo 12  */	
Select Distinct
  an_type
From a_testbed.zoo_ex p1
Where an_price = All (
  Select
    an_price
  From a_testbed.zoo_ex p2
  Where an_price Is Not Null
  And p1.an_type = p2.an_type
);

/*  demo 13  */	
Select Distinct
  an_type
From a_testbed.zoo_ex p1
Where an_price = All (
  Select
    an_price
  From a_testbed.zoo_ex p2
  Where p1.an_type = p2.an_type
);

/*  demo 14  */	
Select
  an_type
From a_testbed.zoo_ex p1
Where an_price = All (
  Select
    an_price
  From a_testbed.zoo_ex p2
  Where an_price Is Not Null
  And p1.an_type = p2.an_type
)
Group By an_type
Having COUNT(*) > 1
;

/*  demo 15  */	
Select Distinct
  an_type
From a_testbed.zoo_ex p1
Where an_price = All (
  Select
    an_price
  From a_testbed.zoo_ex p2
  Where p1.an_type = p2.an_type
)
Group By an_type
Having COUNT(*) > 1
;

/*  demo 16  */	
Select
  PR.prod_id
, PR.prod_name
From a_prd.products PR
Where catg_id = 'HD'
Order By prod_id
;

Select
  PR.prod_id
, PR.prod_name
, PR.prod_list_price
, OD.quoted_price
, PR.prod_list_price - OD.quoted_price As price_diff
From a_prd.products PR
Join a_oe.order_details OD On PR.prod_id = OD.prod_id
Where PR.catg_id = 'HD'
Order By PR.prod_id;

/*  demo 17  */	
Select Distinct
  PR.prod_id
, pr.prod_name
From a_prd.products PR
Join a_oe.order_details OD On PR.prod_id = OD.prod_id
Where catg_id = 'HD'
And prod_list_price > All (
  Select
    quoted_price
  From a_oe.order_details OD2
  Where OD2.prod_id = PR.prod_id
);


/*  demo 18  */	
Select Distinct
  PR.prod_id
, pr.prod_name
From a_prd.products PR
Join a_oe.order_details OD On PR.prod_id = OD.prod_id
Where catg_id = 'HD'
And prod_list_price > Any (
  Select
    quoted_price
  From a_oe.order_details OD2
  Where OD2.prod_id = PR.prod_id
);

/*  demo 19  */	
Select Distinct
  PR.prod_id
, pr.prod_name
From a_prd.products PR
Join a_oe.order_details OD On PR.prod_id = OD.prod_id
Where catg_id = 'HD'
And prod_list_price = All (
  Select
    quoted_price
  From a_oe.order_details OD2
  Where OD2.prod_id = PR.prod_id
);

/*  demo 20  */	
Select Distinct
  PR.prod_id
, pr.prod_name
From a_prd.products PR
Join a_oe.order_details OD On PR.prod_id = OD.prod_id
Where catg_id = 'HD'
And prod_list_price = Any (
  Select
    quoted_price
  From a_oe.order_details OD2
  Where OD2.prod_id = PR.prod_id
);


/*  demo 21  */	
Select prod_id, count(*) as Cnt
From a_oe.order_details  OD 
Group by prod_id
Order by 2;


/*  demo 22  */	
Select ord_id, line_Item_id, prod_id
From a_oe.order_details  OD 
Where ord_id = 312;


/*  demo 23  */	
Select prod_id, count(distinct ord_id) as CntOrders
From a_oe.order_details  OD 
Group by prod_id
order by 2;


/*  demo 24  */	
Select prod_id
From a_oe.order_details  
Group by prod_id
Having count(distinct ord_id) >=
   All(select count(distinct  ord_id)
   From a_oe.order_details 
   Group by prod_id);


/*  demo 25  */	
Select prod_id
From a_oe.order_details  
Group by prod_id
Having sum(quantity_ordered) >=
   All(Select sum(quantity_ordered)
   From a_oe.order_details 
   Group by prod_id);


/*  demo 26  */	
Select prod_id
From a_oe.order_details  
Group by prod_id
Having sum(quantity_ordered*quoted_price) >=
   All(Select sum(quantity_ordered*quoted_price)
   From a_oe.order_details 
   Group by prod_id);


