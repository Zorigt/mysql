Create Table a_testbed.zoo_ex (
  id integer Primary Key
, an_type varchar(15)
, an_price integer
)
;

Truncate Table a_testbed.zoo_ex ;
Insert Into a_testbed.zoo_ex 
  Values (1, 'dog', 80)
  , (2, 'turtle', Null)
  , (3, 'lizard', Null)
  , (4, 'bird', 100)
  , (5, 'bird', 50)
  , (6, 'fish', 10)
  , (7, 'lizard', 50)
  , (8, 'cat', 10)
  , (9, 'snake', 50)
  , (10, 'snake', Null)
  , (11, 'fish', 10)
  , (12, 'lizard', 50)
  , (13, 'fish', 10)
  , (14, 'snake', 25)
  , (15, 'bird', 80)
  , (16, 'cat', Null)
  , (17, 'bird', 80)
;


Select *
From a_testbed.zoo_ex 
Order By an_type, id;

/*  demo 01  */	
Select
  'Found'
From dual
Where Exists (
  Select
    1
  From a_testbed.zoo_ex 
);


/*  demo 02  */	
Select
  'Found'
From dual
Where Exists (
  Select
    1
  From a_testbed.zoo_ex 
  Where an_type = 'snake'
);


/*  demo 03  */	
Select
  'Found'
From dual
Where Exists (
  Select
    1
  From a_testbed.zoo_ex 
  Where an_type = 'penguin'
);

/*  demo 04  */	
Select
  an_price
From a_testbed.zoo_ex 
Where an_type = 'snake'
And an_price Is Null;


/*  demo 05  */	
Select
  'Found'
From dual
Where Exists (
  Select
    an_price
  From a_testbed.zoo_ex 
  Where an_type = 'snake'
  And an_price Is Null
);


/*  demo 06  */	
Select
  'Found'
From dual
Where Exists (
  Select
    an_price
  From a_testbed.zoo_ex 
  Where an_type = 'bird'
  And an_price Is Null
);


/*  demo 07  */	
Select
  *
From zoo_ex
Where an_type = 'bird'
And Exists (
  Select
    1
  From a_testbed.zoo_ex 
  Where an_type = 'bird'
  And an_price < 75
);

Select
  *
From a_testbed.zoo_ex 
Where an_type = 'bird'
And Exists (
  Select
    1
  From a_testbed.zoo_ex 
  Where an_type = 'bird'
  And an_price < 15
);



/*  demo 08  */	
Select
  *
From a_testbed.zoo_ex 
Where an_type = 'bird'
And Not Exists (
  Select
    1
  From a_testbed.zoo_ex 
  Where an_type = 'bird'
  And an_price < 75
);


/*  demo 09  */	
Select
  *
From a_testbed.zoo_ex 
Where an_type = 'bird'
And id In (
  Select
    id
  From a_testbed.zoo_ex 
  Where an_type = 'bird'
  And an_price < 75
);


/*  demo 10  */	
Select
  *
From a_testbed.zoo_ex 
Where an_type = 'snake'
And Exists (
  Select
    1
  From a_testbed.zoo_ex 
  Where an_type = 'snake'
  And an_price < 75
);

/*  demo 10B  */ 
Select
  *
From a_testbed.zoo_ex 
Where an_type = 'snake'
And Exists (
  Select
    1
  From a_testbed.zoo_ex 
  Where an_type = 'snake'
  And an_price < 15
);


/*  demo 11  */	
Select
  *
From a_testbed.zoo_ex 
Where an_type = 'snake'
And Not Exists (
  Select
    1
  From a_testbed.zoo_ex 
  Where an_type = 'snake'
  And an_price < 75
);

/*  demo 11B  */	 
Select
  *
From a_testbed.zoo_ex 
Where an_type = 'snake'
And Not Exists (
  Select
    1
  From a_testbed.zoo_ex 
  Where an_type = 'snake'
  And an_price < 15
);


/*  demo 12  */	
Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where Exists (
  Select
    'X'
  From a_oe.order_headers
  Where a_oe.order_headers.cust_id = a_oe.customers.cust_id
  And EXTRACT(Month From ord_date) = 10
  And EXTRACT(year From ord_date) = 2011
);

/*  demo 13  */	
Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where cust_id In (
  Select
    cust_id
  From a_oe.order_headers
  Where EXTRACT(Month From ord_date) = 10
  And EXTRACT(year From ord_date) = 2011
);

/*  demo 14  */	 This query  may be less efficient  if there is a sort done to handle the distinct. 
Select Distinct
  CS.cust_id
, CS.cust_name_last
, CS.cust_name_first
From a_oe.customers CS
Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
Where EXTRACT(Month From ord_date) = 10
And EXTRACT(year From ord_date) = 2011
;

/*  demo 15  */	 This query can return multiple rows for the same customer.
Select
  CS.cust_id
, CS.cust_name_last
, CS.cust_name_first
From a_oe.customers CS
Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
Where EXTRACT(Month From ord_date) = 10
And EXTRACT(year From ord_date) = 2011
;

/*  demo 16  */	
Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where Exists (
  Select
    1
  From a_oe.order_headers OH
  Join a_oe.order_details OD On OH.ord_id = OD.ord_id
  Join a_prd.products PR On OD.prod_id = PR.prod_id
  Where (prod_list_price - quoted_price) / prod_list_price > 0.1
  And a_oe.customers.cust_id = OH.cust_id
)
Order By cust_id;


/*  demo 17  */	
Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where Not Exists (
  Select
    1
  From a_oe.order_headers OH
  Join a_oe.order_details OD On OH.ord_id = OD.ord_id
  Join a_prd.products PR On OD.prod_id = PR.prod_id
  Where (prod_list_price - quoted_price) / prod_list_price > 0.1
  And a_oe.customers.cust_id = OH.cust_id
)
Order By cust_id
;


/*  demo 18  */	

Select
  cust_id
, cust_name_last
, cust_name_first
From a_oe.customers
Where Exists (
  Select
    1
  From a_oe.order_headers OH
  Join a_oe.order_details OD On OH.ord_id = OD.ord_id
  Join a_prd.products PR On OD.prod_id = PR.prod_id
  Where Not ((prod_list_price - quoted_price) / prod_list_price > 0.1)
  And a_oe.customers.cust_id = OH.cust_id
);

/*  demo 19  */	
Select
  prod_id
, prod_name
From A_prd.products PR
Where Exists (
  Select
    'X'
  From A_oe.order_details OD
  Where PR.prod_id = OD.prod_id
  And quantity_ordered >= 10
);


/*  demo 20  */	
Select
  a_oe.customers.cust_id
, cust_name_last
From a_oe.customers
Where Exists (
  Select
    'X'
  From a_oe.cust_orders
  Where a_oe.cust_orders.custID = A_oe.customers.cust_id
  And category = 'APL'
)
And Exists (
  Select
    'X'
  From a_oe.cust_orders
  Where a_oe.cust_orders.custID = A_oe.customers.cust_id
  And category = 'HW'
);


/*  demo 21  */	
Select
  CS.cust_id
, CS.cust_name_last
, Case
      When Exists (
        Select
          'X'
        From a_oe.cust_orders
        Where a_oe.cust_orders.custID = CS.cust_id
        And category = 'APL'
      ) Then 'Appliances  ' Else '    ---    '
    End As " "
, Case
      When Exists (
        Select
          'X'
        From a_oe.cust_orders
        Where a_oe.cust_orders.custID = CS.cust_id
        And category = 'HW'
      ) Then 'Housewares  ' Else '    ---    '
    End As " "
, Case
      When Exists (
        Select
          'X'
        From a_oe.cust_orders
        Where a_oe.cust_orders.custID = CS.cust_id
        And category = 'PET'
      ) Then 'PetSupplies ' Else '    ---    '
    End As " "
From a_oe.customers CS
;

/*  demo 22  */	
Select
  CS.cust_id
, CS.cust_name_last
, CONCAT(
    Case
      When Exists (
        Select
          'X'
        From a_oe.cust_orders
        Where a_oe.cust_orders.custID = CS.cust_id
        And category = 'APL'
      ) Then 'Appliances  ' Else ''
    End
  , Case
      When Exists (
        Select
          'X'
        From a_oe.cust_orders
        Where a_oe.cust_orders.custID = CS.cust_id
        And category = 'HW'
      ) Then 'Housewares  ' Else ''
    End
  , Case
      When Exists (
        Select
          'X'
        From a_oe.cust_orders
        Where a_oe.cust_orders.custID = CS.cust_id
        And category = 'PET'
      ) Then 'PetSupplies' Else ''
    End) As PurchaseAreas
From a_oe.customers CS;


/*  demo 23  */	
create or replace   view a_oe.Ord as (
   select cust_id as CustID, prod_id  as prodid
   from a_oe.order_headers OH
   join a_oe.order_details OD  on OH.ord_id = OD.ord_id );

Create Or Replace View a_oe.SPG
As (
  Select
    prod_id As spg_prod_id
  From a_prd.products
  Where catg_id = 'SPG'
);


/*  demo 24  */	
Select
  Cust_id
, cust_name_last
From a_oe.customers CS
Where Not Exists (
  Select
    *
  From a_oe.SPG
  Where Not Exists (
    Select
      *
    From a_oe.ORD
    Where a_oe.SPG.spg_prod_id = a_oe.Ord.prodid
    And a_oe.ord.custid = CS.cust_id
  )
);


Select
  prod_id
, prod_name
, catg_id
From a_prd.products
Where catg_id = 'SPG';

Select
  OH.cust_id
, OD.prod_id
, PR.prod_name
, PR.catg_id
From a_oe.order_headers OH
Join a_oe.order_details OD On OH.ord_id = OD.ord_id
Join a_prd.products PR On OD.prod_id = PR.prod_id
Where cust_id In (403000, 408770)
And PR.catg_id = 'SPG'
Order By OH.cust_id, OD.prod_id;

/*  demo 25
Select
  Cust_id
, cust_name_last
From a_oe.customers CS
Where Not Exists (
  Select
    *
  From (
    Select
      prod_id As spg_prod_id
    From a_prd.products
    Where catg_id = 'SPG'
  ) tbl_S
  Where Not Exists (
    Select
      *
    From (
      Select
        cust_id As CustID
      , prod_id As prodid
      From a_oe.order_headers OH
      Join a_oe.order_details OD On OH.ord_id = OD.ord_id
    ) tbl_o
    Where tbl_S.spg_prod_id = tbl_o.prodid
    And tbl_o.custid = CS.cust_id
  )
);

/*  demo 26  */	

Select
  cust_id
, cust_name_last
From (
  Select
    CS.cust_id
  , CS.cust_name_last
  , PR.prod_id
  From a_oe.customers CS
  Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
  Join a_oe.order_details OD On OH.ord_id = OD.ord_id
  Join a_prd.products PR On OD.prod_id = PR.prod_id
  Where catg_id = 'SPG'
) sales
Group By cust_id, cust_name_last
Having COUNT(Distinct prod_id)
= (
  Select
    COUNT(prod_id)
  From a_prd.products PR
  Where catg_id = 'SPG'
);

/*  demo 27  */	
Select
  AllSales.cust_id
, AllSales.cust_name_last
From (
  Select
    CS.cust_id
  , CS.cust_name_last
  , PR.prod_id
  , pr.catg_id
  From a_oe.customers CS
  Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
  Join a_oe.order_details OD On OH.ord_id = OD.ord_id
  Join a_prd.products PR On OD.prod_id = PR.prod_id
) AllSales
Join (
  Select
    CS.cust_id
  , CS.cust_name_last
  , PR.prod_id
  , pr.catg_id
  From a_oe.customers CS
  Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
  Join a_oe.order_details OD On OH.ord_id = OD.ord_id
  Join a_prd.products PR On OD.prod_id = PR.prod_id
  Where catg_id = 'SPG'
) spgSales On AllSales.cust_id = SPGSales.cust_id
Cross Join (
  Select
    COUNT(prod_id) As NumToys
  From a_prd.products PR
  Where catg_id = 'SPG'
) ToyCount
Group By AllSales.cust_id, AllSales.cust_name_last, ToyCount.NumToys
Having COUNT(Distinct spgSales.prod_id)
= ToyCount.NumToys
And COUNT(Distinct allsales.prod_id)
= ToyCount.NumToys
;