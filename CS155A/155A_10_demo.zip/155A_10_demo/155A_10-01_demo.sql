
/*  demo 01  */
Select
  emp_id
, name_last As "Employee"
From a_emp.employees
Where dept_id = (
  Select
    dept_id
  From a_emp.employees
  Where emp_id = 162
);

/*  demo 02  */
Select
  emp_id
, name_last As "Employee"
From a_emp.employees
Where dept_id = (
  Select
    dept_id
  From a_emp.employees
);

/*  demo 03  */
Select
  emp_id
, name_last As "Employee"
From a_emp.employees
Where dept_id = (
  Select
    dept_id
  From a_emp.employees
  Where name_last = 'Green'
);

/*  demo 04  */
Set @catg   := 'MUS';

Select
  AVG(prod_list_price)
From a_prd.products
Where catg_id = @catg;

/*  demo 05  */
Select
  prod_id
, prod_name
, prod_list_price
From a_prd.products
Where catg_id = @catg
And prod_list_price Between (
  Select
    0.9 * AVG(prod_list_price)
  From a_prd.products
  Where catg_id = @catg
) And (
  Select
    1.1 * AVG(prod_list_price)
  From a_prd.products
  Where catg_id = @catg
);

/*  demo 06  */
Select
  AVG(salary)
From a_emp.employees;

Select
  emp_id
, name_last
, salary
, (
    Select
      AVG(salary)
    From a_emp.employees
  ) As MedSalary
From a_emp.employees;

/*  demo 07  */
Select
  emp_id
, name_last
, salary
, ROUND(salary - (
    Select
      AVG(salary)
    From a_emp.employees
  ), 0) As "Over/Under"
From a_emp.employees;



/*  demo 08  */
Select
  dept_id
, emp_id
, name_last
, salary
, ROUND(salary - (
    Select
      AVG(salary)
    From a_emp.employees
  ), 0) As "Over/Under"
From a_emp.employees
Where dept_id In (30)
Order By ABS(salary - (Select AVG(salary) From a_emp.employees));

/*  demo 09  */
Select
  prod_id
, prod_name
, catg_id
, prod_list_price - (
    Select
      ROUND(AVG(prod_list_price), 2)
    From a_prd.products
  ) As "Over/Under Avg Price"
From a_prd.products
Order By catg_id
;

/*  demo 10  */
Select
  cust_id
, ord_id
, (
    Select
      SUM(quantity_ordered)
    From a_oe.order_details OD
  ) As "NumItems"
From a_oe.order_headers OH
Limit 5
;

/*  demo 11  */
Select
  cust_id
, ord_id
, (
    Select
      SUM(quantity_ordered)
    From a_oe.order_details OD
    Where OH.ord_id = OD.ord_id
  ) As "NumItemsPerOrder"
From a_oe.order_headers OH
Limit 10
;

/*  demo 12  */	
Select
  cust_id
, ord_id
, COALESCE((
    Select
      SUM(quantity_ordered)
    From a_oe.order_details
    Where a_oe.order_headers.ord_id =
    a_oe.order_details.ord_id
  ), 0) As "NumitemsPerOrder"
From a_oe.order_headers
Order By NumItemsPerOrder
;

/*  demo 13  */	
Select
  cust_id
, ord_id
, SUM(quantity_ordered) As NumItemsPerOrder
From a_oe.order_headers ORD
Left Join a_oe.order_details ORDT Using (ord_id)
Group By cust_id, ord_id
Order By NumItemsPerOrder
;


/*  demo 14  */	
Select
  cust_id
, ord_id
, (
    Select
      SUM(quantity_ordered)
    From a_oe.order_details
    Where a_oe.order_headers.ord_id =
    a_oe.order_details.ord_id
  ) As "NumPerOrder"
, (
    Select
      SUM(quantity_ordered * quoted_price)
    From a_oe.order_details
    Where a_oe.order_headers.ord_id =
    a_oe.order_details.ord_id
  ) As "OrderCost"
From a_oe.order_headers
Limit 8;