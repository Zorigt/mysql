
/*  demo 01  */	
Select
  CS.cust_name_last
, CS.cust_name_first
From a_oe.customers CS
Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
Order By CS.cust_name_last, CS.cust_name_first;

/*  demo 02  */	
Select Distinct
  CS.cust_name_last
, CS.cust_name_first
From a_oe.customers CS
Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
Order By cust_name_last, cust_name_first;

/*  demo 03  */	
Select Distinct
  CS.cust_name_last
, CS.cust_name_first
, CS.cust_id
From a_oe.customers CS
Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
Order By cust_name_last, cust_name_first;

/*  demo 04  */	
Select
  cust_name_last
, cust_name_first
From (
  Select Distinct
    CS.cust_name_last
  , CS.cust_name_first
  , CS.cust_id
  From a_oe.customers CS
  Join a_oe.order_headers OH On CS.cust_id = OH.cust_id
) CS
;

/*  demo 05  */	
Select
  cust_name_last
, cust_name_first
From a_oe.customers CS
Where cust_id In (
  Select
    cust_id
  From a_oe.order_headers
);

/*  demo 06  */	
Select
  dept_id
, dept_name
, loc_type As LocationType
From a_emp.departments D
Left Join a_emp.locations L On D.loc_id = L.loc_id
Order By dept_id
;

/*  demo 07  */	
Select
  dept_id
, l.loc_id
, loc_type As LocationType
, loc_city As City
, loc_state_province As "State/Province"
From a_emp.departments D
Left Join a_emp.locations L On D.loc_id = L.loc_id
Order By dept_id
;

/*  demo 08  */	
Select
  dept_id
, COALESCE(loc_type, 'Unknown type') As LocationType
, COALESCE(loc_city, 'No Site') As City
, COALESCE(loc_state_province, 'No Site') As "State/Province"
From a_emp.departments D
Left Join a_emp.locations L On D.loc_id = L.loc_id
Order By dept_id
;

/*  demo 09  */	
Select
  dept_id
, COALESCE(loc_type, 'No Site') As LocationType
, COALESCE(loc_city, 'No Site') As City
, COALESCE(loc_state_province, 'No Site') As "State/Province"
From a_emp.departments D
Left Join (
  Select
    loc_id
  , COALESCE(loc_type, 'UnknownType') As loc_type
  , loc_city
  , loc_state_province
  From a_emp.locations
) L On D.loc_id = L.loc_id
Order By dept_id
;