
/*  demo 01  */	
Select
  AVG(prod_list_price) As avgprice
From a_prd.products
;

/*  demo 02  */	
Select
  prod_id
, prod_list_price
, catg_id
From a_prd.products
Where prod_list_price > (
  Select
    AVG(prod_list_price)
  From a_prd.products
);

/*  demo 03  */	
Select
  AVG(prod_list_price) As avgPrice
, catg_id
From a_prd.products
Group By catg_id
;

/*  demo 04  */	
Select
  prod_id
, catg_id
, prod_list_price
From a_prd.products Otr
Where prod_list_price > (
  Select
    AVG(prod_list_price)
  From a_prd.products Inr
  Where Otr.catg_id = Inr.catg_id
)
Order By catg_id, prod_list_price;

/*  demo 05  */	
Create Or Replace View a_oe.OE_OrdExtTotal
As
Select
  ord.cust_id
, ord.ord_id
, SUM(odt.Quantity_ordered * odt.quoted_price) As ordertotal
From a_oe.order_headers ord
Join a_oe.order_details odt On ord.ord_id = odt.ord_id
Group By ord.cust_id, ord.ord_id;

/*  demo 06  */	
Select
  cust_id
, ROUND(AVG(ordertotal), 2) frm_avg
, 1.25 * ROUND(AVG(ordertotal), 2) cut_off
From a_oe.OE_OrdExtTotal
Group By cust_id
;

/*  demo 07  */	
Select
  cust_id
, ord_id
, ordertotal
From a_oe.OE_OrdExtTotal OTR
Where OrderTotal > 1.25 * (
  Select
    ROUND(AVG(ordertotal), 2)
  From a_oe.OE_OrdExtTotal INR
  Where OTR.Cust_id = INR.Cust_id
  Group By cust_id
);

/*  demo 08  */	
Select
  cust_id
, cust_name_last
From a_oe.customers C
Where 1 < (
  Select
    COUNT(*)
  From a_oe.order_headers
  Where cust_id = C.cust_id
);

/*  demo 09  */
Select
  cust_id
, cust_name_last
, Case (
      Select
        COUNT(*)
      From a_oe.order_headers OH
      Where OH.cust_id = CS.cust_id
    )
      When 0 Then '. . . No orders'
      When 1 Then '1 order'
      When 2 Then '2 orders'
      When 3 Then '3 orders' Else '4+ orders'
    End As NumberOfOrders
From a_oe.customers CS;