Use a_oe;

/*  demo 01  */
Select
  emp_id
, name_last As "Employee"
, salary
From a_emp.employees
Where salary Between 3000 And 12000;

/*  demo 02  */
Select
  emp_id
, name_last As "Employee"
, salary
From a_emp.employees
Where salary Not Between 10000 And 60000
Order By salary;

/*  demo 03  */
Select
  emp_id
, name_last As "Employee"
, hire_date
From a_emp.employees
Where hire_date Between '2001-01-01' And '2007-12-31';

/*  demo 04  */
Select
  emp_id
, name_last As "Employee"
, dept_id
From a_emp.employees
Where name_last Between 'J' And 'T'
Order By name_last;

/*  demo 05  */
Select
  cust_id
, cust_name_last
, cust_name_first
, credit_limit
From a_oe.customers
Where credit_limit Between 0 And 1000;

/*  demo 06  */
Select
  cust_id
, cust_name_last
, cust_name_first
, credit_limit
From a_oe.customers
Where credit_limit Is Null;

/*  demo 07  */
Select
  emp_id
, name_last As "Employee"
, salary
From a_emp.employees
Where salary Between 3000 And 1000;

/*  demo 08  */
Select
  emp_id
, name_last As "Employee"
, salary
From a_emp.employees
Where salary Between 3000 And Null;

/*  demo 09  */
Select
  emp_id
, name_last As "Employee"
, salary
From a_emp.employees
Where salary Between Null And 1000;

/*  demo 10  */
Select stf_id, ex_date
from a_vets.vt_exam_headers
where month(ex_date) = 4 and year(ex_date) = 2013
order by ex_date;


/*  demo 11  */
Select stf_id, ex_date
from a_vets.vt_exam_headers
where ex_date between '2013-04-01' and '2013-04-30'
order by ex_date;


/*  demo 12  */
Select stf_id, ex_date
from a_vets.vt_exam_headers
where ex_date between '2013-04-01' and '2013-04-30 23:59:59';


/*  demo 13  */
Select
  emp_id
, name_last As "Employee"
, salary
From a_emp.employees
Where salary = 12000;

/*  demo 14  */
Select
  emp_id
, name_last As "Employee"
, salary
From a_emp.employees
Where salary = 18888;

/*  demo 15  */
Select
  loc_city
, loc_street_address
From a_emp.locations
Where loc_country_id = 'US';

/*  demo 16  */
Select
  loc_city
, loc_street_address
From a_emp.locations
Where loc_city = 'SAN FRANCISCO';

/*  demo 17  */
Select
  ord_id
, cust_id
, ord_mode
From a_oe.order_headers
Where ord_date = '2012-12-15';

/*  demo 18  */
Select
  prod_id
, prod_name
, catg_id
, prod_warranty_period
From a_prd.products
Where row(catg_id, prod_warranty_period) = row('HW', 12);

/*  demo 19 */
Select
  loc_city
, loc_street_address
From a_emp.locations
Where loc_country_id != 'US';

/*  demo 20  */
Select
  job_id
, max_salary
, job_title
From a_emp.jobs
Where max_salary < 60000;

/*  demo 21  */
Select
  job_id
, max_salary
, job_title
From a_emp.jobs
Where max_salary >= 60000;

/*  demo 22  */
Select
  emp_id
, name_last As "Employee"
, salary
From a_emp.employees
Where salary = '15000';

/*  demo 23  */
Select
  emp_id
, hire_date
From a_emp.employees
Where hire_date < 34567;