-- CS 155A  MySQL
-- this will create the schema (databases) needed
CREATE SCHEMA IF NOT EXISTS a_bkinfo;

CREATE SCHEMA IF NOT EXISTS a_bkorders; 
